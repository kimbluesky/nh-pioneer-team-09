#!/usr/bin/env python3
"""ZIP direct runner: verify source hashes before importing the original engine."""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

COMMIT = "3311fb4e82aad59ef176599a67f21666b07e926c"


def main() -> int:
    parser = argparse.ArgumentParser(description="R17: 해외 일봉 자정 조기 마감 오프라인 검증")
    parser.add_argument("--output", type=Path, help="JSON 저장 경로; 기존 파일 덮어쓰지 않음")
    args = parser.parse_args()
    root = Path.cwd()
    if not (root / "backend" / "strategy" / "bars.py").exists():
        print("FAIL: NH 프로젝트 최상위 폴더(backend/ 포함)에서 실행해야 합니다.")
        return 2

    with zipfile.ZipFile(Path(sys.argv[0])) as z:
        manifest = json.loads(z.read("source_manifest.json"))
    if manifest.get("commit") != COMMIT:
        print("FAIL: manifest commit mismatch")
        return 2
    mismatch = 0
    for item in manifest["files"]:
        relative = item["path"]
        file_path = root / relative
        if not file_path.is_file():
            print(f"FAIL (missing): {relative}")
            mismatch += 1
        else:
            actual = hashlib.sha256(file_path.read_bytes()).hexdigest()
            if actual != item["sha256"]:
                print(f"FAIL (SHA-256 mismatch): {relative}")
                print(f"  actual:   {actual}")
                print(f"  expected: {item['sha256']}")
                mismatch += 1
            else:
                print(f"PASS: {relative}")
    count = len(manifest["files"])
    if mismatch:
        print(f"FAIL R17_SOURCE_INTEGRITY: {mismatch}/{count} files differ from commit {COMMIT[:7]}")
        print("검증에 사용한 프로젝트를 해당 커밋 버전으로 바꿔야 합니다. JSON commit 값만 바꾸면 안 됩니다.")
        return 3
    print(f"PASS R17_SOURCE_INTEGRITY: {count}/{count}, commit {COMMIT[:7]}")
    # When running a zipapp the current working directory might be absent from sys.path.
    sys.path.insert(0, str(root))
    from verify_R17 import main as reproduce
    try:
        success = reproduce(args.output)
    except FileExistsError:
        print("FAIL: --output 경로가 이미 존재합니다. 기존 결과는 덮어쓰지 않습니다.")
        return 4
    return 0 if success else 1

if __name__ == "__main__":
    raise SystemExit(main())
