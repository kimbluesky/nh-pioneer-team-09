#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R17 해외 일봉 한국 자정 분리/조기주문 재현 — NH FUTURES API 원본 코드 사용.

실행: 프로젝트 최상위 폴더에서 `python -B reproduce_R17.zip`
외부 요청/실제 주문 없이 paper(가상 장부)만 사용합니다.
"""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from pathlib import Path

from backend.sessions.hours import KST
from backend.strategy import engine, runs

SYMBOL = "6AZ26"
CONTEXT = "overseas"
BASE_DAY = date(2026, 11, 5)


def ms(day: int, hour: int, minute: int, second: int = 0) -> int:
    return int(datetime(2026, 11, day, hour, minute, second, tzinfo=KST).timestamp() * 1000)


def iso(value: int) -> str:
    return datetime.fromtimestamp(value / 1000, tz=KST).isoformat(timespec="seconds")


def trading_day(ts: int) -> date:
    """재현용 시간표: 08:00 개장 → 다음 날 07:00 마감 (KST).

    실제 NH 장운영정보를 수집한 시간표가 아닌 통제된 테스트 조건입니다.
    자정 전후 두 체결은 모두 2026-11-05 거래일로 귀속됩니다.
    """
    moment = datetime.fromtimestamp(ts / 1000, tz=KST)
    return moment.date() if moment.hour >= 8 else moment.date() - timedelta(days=1)


def draft() -> dict:
    return {
        "baseBar": "일봉", "evalMode": "마감",
        "rules": {
            "buyEntry": {
                "on": True,
                "steps": [{
                    "id": "step1", "join": "all", "withinBars": 0,
                    "conds": [{
                        "id": "close_above_065", "left": "close", "op": "gt",
                        "rightKind": "number", "right": "0.65",
                    }],
                }],
            },
            "sellEntry": {"on": False, "steps": []},
            "buyExit": {"on": False, "steps": []},
            "sellExit": {"on": False, "steps": []},
        },
        "aux": {
            "orderType": "시장가", "priceBasis": "신호가",
            "stopBasis": "", "fillCond": "",
            "stopTicks": "1000", "takeTicks": "",
            "perOrder": "1", "maxHold": "1",
            "session": "해외 CME", "addWhileOpen": False,
            "dailyLoss": "10000", "marginBudget": "100000",
        },
    }


def seed_bar(day: int) -> dict:
    # 시세 조회로 확보한 '완성 일봉' 2개를 재현 입력으로 준비.
    return {
        "timestamp": ms(day, 8, 0),
        "open": 0.64, "high": 0.64, "low": 0.64, "close": 0.64, "volume": 10,
    }


def scenario(name: str, first: int, second: int) -> dict:
    run = runs.Run(
        id=f"r17-{name}", version_id="synthetic-v1", code=SYMBOL,
        session=CONTEXT, market="overseas", exchange="FCME",
        mode=runs.PAPER, state=runs.ARMED,
        draft=draft(), qty=1, cash=100_000.0, multiplier=1.0,
        margin=None, margin_budget=100_000.0, daily_loss=10_000.0,
    )
    bot = engine.RunEngine(run, tick=0.0001, gap_seconds=30)
    # 엔진의 거래일 판정은 올바르게 공급. 그러나 BarBuilder 는 이 함수를 받지 않음.
    bot.trading_day = trading_day
    bot.seed([seed_bar(3), seed_bar(4)], CONTEXT)
    bot.note_open(CONTEXT, ms(5, 8, 0))

    events_before = len(bot.events)
    bot.on_trade({"timestamp": first, "price": 0.66, "quantity": 1}, CONTEXT, at=first)
    first_state = {
        "at": iso(first),
        "trading_day": str(trading_day(first)),
        "closed_bars": len(bot.bars.bars),
        "open_bar_start": iso(bot.bars.open_bar.timestamp) if bot.bars.open_bar else None,
        "order_count": len(bot.book.orders),
        "engine_day_key": iso(bot.run.day_key) if bot.run.day_key else None,
    }
    bot.on_trade({"timestamp": second, "price": 0.67, "quantity": 1}, CONTEXT, at=second)
    after = {
        "at": iso(second),
        "trading_day": str(trading_day(second)),
        "closed_bars": len(bot.bars.bars),
        "last_closed_bar": (
            {"start": iso(bot.bars.bars[-1].timestamp),
             "close": bot.bars.bars[-1].close,
             "volume": bot.bars.bars[-1].volume}
            if len(bot.bars.bars) > 2 else None
        ),
        "open_bar_start": iso(bot.bars.open_bar.timestamp) if bot.bars.open_bar else None,
        "open_bar_price": bot.bars.open_bar.close if bot.bars.open_bar else None,
        "order_count": len(bot.book.orders),
        "signal_count": bot.signal_count,
        "engine_day_key": iso(bot.run.day_key) if bot.run.day_key else None,
        "order_details": [
            {"id": o.id, "side": o.side, "quantity": o.quantity,
             "type": o.order_type, "price": o.price}
            for o in bot.book.orders
        ],
        "events_after_first_trade": [
            {"time": iso(e["time"]), "kind": e["kind"], "text": e["text"]}
            for e in bot.events[events_before:]
        ],
        "condition_table_present": bot._conditions is not None,
    }
    return {"case": name, "first": first_state, "second": after}


def main(output_path: Path | None = None) -> bool:
    control = scenario("control_before_midnight", ms(5, 23, 59, 57), ms(5, 23, 59, 59))
    crossing = scenario("cross_midnight", ms(5, 23, 59, 59), ms(6, 0, 0, 1))

    # 재현 전후를 비교하며, 고친 버전에서도 항상 로그를 저장합니다.
    control_ok = (
        control["second"]["trading_day"] == str(BASE_DAY)
        and control["second"]["closed_bars"] == 2
        and control["second"]["order_count"] == 0
    )
    same_trade_day = (
        crossing["first"]["trading_day"]
        == crossing["second"]["trading_day"]
        == str(BASE_DAY)
    )
    wrong_midnight_close = (
        crossing["second"]["closed_bars"] == 3
        and crossing["second"]["last_closed_bar"] is not None
        and crossing["second"]["last_closed_bar"]["close"] == 0.66
        and crossing["second"]["open_bar_price"] == 0.67
    )
    premature_order = (
        crossing["second"]["order_count"] == 1
        and crossing["second"]["order_details"][0]["side"] == "buy"
        and crossing["second"]["order_details"][0]["quantity"] == 1
    )
    bug_reproduced = control_ok and same_trade_day and wrong_midnight_close and premature_order
    summary = {
        "test_name": "R17: overseas daily closes at KST midnight",
        "source": "Original RunEngine + BarBuilder; 2 synthetic daily seed bars; synthetic fills",
        "case_type": "offline deterministic regression test (no API calls)",
        "expected_correct_behavior": "same trading day -> no new closed bar and no order at midnight",
        "checks": {
            "control_ok": control_ok,
            "same_trade_day": same_trade_day,
            "wrong_midnight_close": wrong_midnight_close,
            "premature_order": premature_order,
        },
        "bug_reproduced": bug_reproduced,
        "control": control,
        "crossing": crossing,
    }
    summary["repository"] = "PetterChanHyuk/nh-futures-open-api"
    summary["commit"] = "3311fb4e82aad59ef176599a67f21666b07e926c"
    summary["error_id"] = "R17"
    if output_path is not None:
        # Exclusive creation: never overwrite an existing file.
        with output_path.open("x", encoding="utf-8") as output_file:
            json.dump(summary, output_file, ensure_ascii=False, indent=2)
            output_file.write("\n")
        print(f"JSON 결과: {output_path.resolve()}")

    print(f"대조군 23:59:57→23:59:59 : 닫힌 일봉 {control['second']['closed_bars']}개, 주문 {control['second']['order_count']}개")
    print(f"재현군 23:59:59→00:00:01 : 닫힌 일봉 {crossing['second']['closed_bars']}개, 주문 {crossing['second']['order_count']}개")
    print(f"같은 거래일: {crossing['first']['trading_day']} == {crossing['second']['trading_day']}")
    print(f"조기 마감 일봉 종가: {crossing['second']['last_closed_bar']['close'] if crossing['second']['last_closed_bar'] else None}")
    print(f"주문: {crossing['second']['order_details']}")
    print(f"거래일 키: {crossing['first']['engine_day_key']} → {crossing['second']['engine_day_key']}")
    if bug_reproduced:
        print("[BUG REPRODUCED] R17 해외 일봉 자정 조기 마감 및 매수 시장가 1계약 생성")
    else:
        print("FAIL R17_OVERSEAS_DAILY_MIDNIGHT: 예상한 오류 패턴이 나오지 않았습니다.")
    return bool(bug_reproduced)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="R17 overseas daily premature close regression")
    parser.add_argument("--output", type=Path, help="새 JSON 결과 파일 생성 (덮어쓰기 없음)")
    args = parser.parse_args()
    raise SystemExit(0 if main(args.output) else 1)
