#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R24: strategy rule numeric-zero comparison ignored by the original evaluator.

Offline reproduction using UNMODIFIED bundled backend source and synthetic bars.
The script makes no API/websocket/account calls and sends no orders.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

REPORT_ID = "R24"


def verify_integrity() -> dict[str, Any]:
    archive = Path(sys.argv[0]).resolve()
    if not zipfile.is_zipfile(archive):
        raise RuntimeError("ZIP 파일을 직접 실행하세요: py -3.12 -B reproduce_R24.zip")
    with zipfile.ZipFile(archive, "r") as zf:
        manifest = json.loads(zf.read("source_manifest.json"))
        checked = []
        for entry in manifest["files"]:
            raw = zf.read(entry["path"])
            found = hashlib.sha256(raw).hexdigest()
            checked.append({
                "path": entry["path"],
                "bytes": len(raw),
                "sha256": found,
                "expected_sha256": entry["sha256"],
                "matched": found == entry["sha256"] and len(raw) == entry["bytes"],
            })
    return {
        "passed": bool(checked) and all(row["matched"] for row in checked),
        "count": len(checked),
        "source_zip_name": manifest["source_zip_name"],
        "source_archive_sha256": manifest["source_archive_sha256"],
        "git_commit_independently_verified": False,
        "files": checked,
    }


def make_bars():
    from backend.strategy.indicators import Bar
    from backend.sessions.hours import KST

    base = datetime(2026, 11, 19, 10, 0, tzinfo=KST)
    # The first bar has zero volume, the second has 12. The PL changes +5 to -5.
    volumes = [0, 12, 14]
    bars = []
    for i, volume in enumerate(volumes):
        t = int((base + timedelta(minutes=i * 5)).timestamp() * 1000)
        bars.append(Bar(timestamp=t, open=100, high=101, low=99, close=100, volume=volume))
    marks = {
        bars[i].timestamp: {"openPl": pl, "positionQty": 1.0}
        for i, pl in enumerate([5.0, -5.0, -7.0])
    }
    return bars, marks


def condition(name: str, right: Any) -> dict[str, Any]:
    return {
        "id": "R24-condition",
        "left": "volume" if name == "volume_entry" else "openPl",
        "op": "gt" if name == "volume_entry" else "lt",
        "rightKind": "number",
        "right": right,
    }


def make_rule(cond: dict[str, Any]) -> dict[str, Any]:
    return {"on": True, "steps": [{"id": "step-1", "join": "all", "conds": [cond]}]}


def full_draft(name: str, cond: dict[str, Any]) -> tuple[dict[str, Any], str]:
    entry = make_rule({"left": "close", "op": "gt", "rightKind": "number", "right": "9999"})
    target = "buyEntry" if name == "volume_entry" else "buyExit"
    rules = {"buyEntry": make_rule(cond) if target == "buyEntry" else entry}
    if target == "buyExit":
        rules["buyExit"] = make_rule(cond)
    draft = {
        "baseBar": "5분봉",
        "rules": rules,
        "aux": {
            "perOrder": 1,
            "maxHold": 1,
            "dailyLoss": 1000,
            "marginBudget": 5000,
            "stopTicks": 2,
            "orderType": "시장가",
            "session": "국내 주간",
            "fillCond": "FAS",
        },
    }
    return draft, target


def scenario(name: str, *, kind: str, right: Any) -> dict[str, Any]:
    from backend.strategy import rules, validate

    bars, marks = make_bars()
    wanted = []
    series = rules.series_of(bars, marks=marks, wanted=wanted)
    cond = condition(kind, right)
    draft, target = full_draft(kind, cond)
    validation = validate.problems(draft, market="domestic")
    rule = draft["rules"][target]
    operator_key = cond["left"]
    results = rules.evaluate(draft["rules"], series, 1)
    right_value = rules.right_at(cond, series, 1)
    return {
        "case": name,
        "target_rule": target,
        "input_right": right,
        "input_right_type": type(right).__name__,
        "comparison": f"{operator_key} {cond['op']} {right!r}",
        "left_values": [series.at(operator_key, i) for i in range(series.length)],
        "valid_to_store": not validate.blocked(validation),
        "validation_problems": validation,
        "parsed_right_at_bar_1": right_value,
        "condition_at_previous_bar": rules.cond_at(cond, series, 0),
        "condition_at_target_bar": rules.cond_at(cond, series, 1),
        "step_at_target": rules.step_at(rule["steps"][0], series, 1),
        "unknown_before": rules._unknown_before(rule["steps"][0], series, 0),
        "fired_bars": rules.fired_bars(rule, series),
        "fired_rules_at_target": results,
        "expected_target_signal": True,
    }


def evaluate() -> dict[str, Any]:
    source = verify_integrity()
    if not source["passed"]:
        raise RuntimeError("FAIL R24_SOURCE_INTEGRITY: 원본 Python 파일의 SHA-256 불일치")

    cases = {}
    for kind in ("volume_entry", "openpl_exit"):
        for suffix, right in (
            ("integer_zero", 0),
            ("string_zero_control", "0"),
            ("float_zero", 0.0),
            ("string_float_zero_control", "0.0"),
            ("integer_one_control", 1),
            ("string_one_control", "1"),
        ):
            cases[f"{kind}__{suffix}"] = scenario(f"{kind}__{suffix}", kind=kind, right=right)

    def case(kind: str, suffix: str) -> dict[str, Any]:
        return cases[f"{kind}__{suffix}"]

    checks = {}
    for kind, tag in (("volume_entry", "volume"), ("openpl_exit", "openpl")):
        numeric = case(kind, "integer_zero")
        text = case(kind, "string_zero_control")
        float_zero = case(kind, "float_zero")
        text_float_zero = case(kind, "string_float_zero_control")
        nonzero = case(kind, "integer_one_control")
        text_nonzero = case(kind, "string_one_control")
        target = numeric["target_rule"]
        checks[f"{tag}_number_zero_is_accepted_by_validator"] = (
            numeric["valid_to_store"] and numeric["validation_problems"] == []
            and text["valid_to_store"]
        )
        checks[f"{tag}_numeric_zero_is_parsed_as_missing"] = (
            numeric["parsed_right_at_bar_1"] is None
            and numeric["fired_bars"] == []
            and numeric["fired_rules_at_target"] == []
        )
        checks[f"{tag}_string_zero_control_fires"] = (
            text["parsed_right_at_bar_1"] == 0.0
            and text["condition_at_previous_bar"] is False
            and text["condition_at_target_bar"] is True
            and text["fired_bars"] == [1]
            and text["fired_rules_at_target"] == [target]
        )
        checks[f"{tag}_float_zero_same_bug"] = (
            float_zero["parsed_right_at_bar_1"] is None
            and float_zero["fired_bars"] == []
            and text_float_zero["fired_bars"] == [1]
        )
        checks[f"{tag}_nonzero_numeric_and_string_controls_agree"] = (
            nonzero["valid_to_store"] and text_nonzero["valid_to_store"]
            and nonzero["fired_bars"] == text_nonzero["fired_bars"] == [1]
            and nonzero["parsed_right_at_bar_1"] == text_nonzero["parsed_right_at_bar_1"] == 1.0
        )
        checks[f"{tag}_previous_context_present_and_not_R22"] = (
            numeric["unknown_before"] is False and text["unknown_before"] is False
            and numeric["left_values"] == text["left_values"]
        )
    checks["all_twelve_cases_validation_passed"] = all(c["valid_to_store"] and c["validation_problems"] == [] for c in cases.values())
    checks["only_json_value_type_differs_in_each_zero_pair"] = all(
        case(kind, "integer_zero")["left_values"] == case(kind, "string_zero_control")["left_values"]
        for kind in ("volume_entry", "openpl_exit")
    )

    return {
        "report_id": REPORT_ID,
        "title": "유효한 숫자 0 비교값이 None으로 처리돼 거래량 진입 및 평가손익 청산 신호 누락",
        "environment": "offline synthetic bars and P/L marks; no NH API, websocket, account or order send",
        "python_runtime": platform.python_version(),
        "source_integrity": source,
        "original_functions_executed": [
            "backend.strategy.validate.problems",
            "backend.strategy.validate.blocked",
            "backend.strategy.rules.series_of",
            "backend.strategy.rules.right_at",
            "backend.strategy.rules.cond_at",
            "backend.strategy.rules.step_at",
            "backend.strategy.rules._unknown_before",
            "backend.strategy.rules.fired_bars",
            "backend.strategy.rules.evaluate",
        ],
        "expected": "JSON number 0 and JSON string '0' must mean the same numeric threshold in an accepted strategy",
        "observed": "number 0/0.0 yields right_at=None and no signal; string '0'/'0.0' emits the expected signal",
        "checks": checks,
        "checks_passed": sum(checks.values()),
        "checks_total": len(checks),
        "bug_reproduced": bool(all(checks.values())),
        "cases": cases,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="R24 숫자 0 비교값 신호 누락 재현")
    parser.add_argument("--output", type=Path, help="결과 JSON을 새 파일로 저장(덮어쓰기 금지)")
    args = parser.parse_args()
    result = evaluate()
    n = result["source_integrity"]["count"]
    print(f"PASS R24_SOURCE_INTEGRITY: {n}/{n}")
    for group in ("volume_entry", "openpl_exit"):
        print(f"[{group}]")
        for suffix in ("integer_zero", "string_zero_control", "float_zero", "string_float_zero_control", "integer_one_control", "string_one_control"):
            c = result["cases"][f"{group}__{suffix}"]
            print(f"  {suffix}: validator={'PASS' if c['valid_to_store'] else 'BLOCK'} | "
                  f"right={c['parsed_right_at_bar_1']} | fired={c['fired_bars']}")
    print(f"CHECKS: {result['checks_passed']}/{result['checks_total']}")
    if args.output is not None:
        with args.output.open('x', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
            f.write('\n')
        print(f"결과 JSON 생성: {args.output}")
    if result["bug_reproduced"]:
        print("[BUG REPRODUCED] R24 숫자 0 비교값에서 매수 진입 및 보유 청산 조건 신호 누락")
        return 0
    print("[NOT REPRODUCED] R24: 예상한 신호 누락을 확인하지 못함")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
