from verify_R24 import main

if __name__ == "__main__":
    raise SystemExit(main())
