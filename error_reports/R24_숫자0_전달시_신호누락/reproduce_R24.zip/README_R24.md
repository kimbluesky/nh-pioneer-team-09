R24 숫자 0 비교값 입력 시 매수 진입·청산 조건 신호 누락 / team-09

실행 방법
1. reproduce_R24.zip을 원하는 폴더에 둡니다. NH 프로젝트를 별도 설치하거나 ZIP을 풀 필요는 없습니다.
2. 탐색기 주소 칸에 powershell을 입력하고 Enter를 누릅니다.
3. 아래 명령을 실행합니다. Python 3.12 이상을 권장합니다.
   py -3.12 -B reproduce_R24.zip
   NH 프로젝트에 .venv가 준비되어 있다면 다음 명령도 사용할 수 있습니다.
   .\.venv\Scripts\python.exe -B reproduce_R24.zip
4. PASS R24_SOURCE_INTEGRITY와 [BUG REPRODUCED] R24을 확인합니다.
   PASS R24_SOURCE_INTEGRITY: 11/11
   volume_entry: 숫자 0 → 신호 없음 / 문자열 "0" → 매수 신호 1건
   openpl_exit: 숫자 0 → 신호 없음 / 문자열 "0" → 매수 보유 청산 신호 1건
   CHECKS: 14/14
   [BUG REPRODUCED] R24 숫자 0 비교값에서 매수 진입 및 보유 청산 조건 신호 누락
   [BUG REPRODUCED]는 원본 함수에서 오류가 재현됐다는 뜻이며, 수정 완료를 뜻하지 않습니다.
   JSON 저장이 필요하면 명령 끝에 --output R24_result.json을 붙입니다.

검증 대상
공개 원본: PetterChanHyuk/nh-futures-open-api
원본 저장소: https://github.com/PetterChanHyuk/nh-futures-open-api
검증한 소스: nh-futures-open-api-main.zip

원본 backend/strategy/validate.py의 problems·blocked와 backend/strategy/rules.py의 series_of·right_at·cond_at·step_at·fired_bars·evaluate를 호출합니다.
원본 Python 소스 11개(패키지 파일, 조건 평가·검사 및 그 종속 모듈)를 수정하지 않고 ZIP에 포함했습니다.
source_manifest.json에는 업로드된 원본 ZIP에서 추출한 파일 11개의 바이트 길이와 SHA-256이 기록되어 있습니다.
실행 시 ZIP 내부 파일 11개를 해당 SHA-256과 비교합니다.
조건, 거래량, 봉, 평가손익값은 검증용 합성 입력입니다. 실제 앱 UI에서 숫자 0을 입력하는 경로는 재현하지 않았으며, API/JSON 등에서 조건의 right 값을 숫자 타입으로 전달하는 상황에 대한 재현입니다.
NH 서버·웹소켓·계좌 호출 및 토큰·APP Key 사용이 없고 외부 의존성 설치가 필요하지 않습니다.
--output 인수를 주지 않으면 결과 파일을 생성하지 않습니다.

설정
기준 봉: 국내 주간, 5분봉(원본 조건 판정 함수에 합성 봉 입력)
매수 진입 조건: 거래량 volume > 0
매수 보유 청산 조건: 평가손익 openPl < 0
조건 결합: 단일 단계 all(모든 조건 충족)
동일한 나머지 설정: 시장가/FAS, 주문당 1계약, 최대 보유 1계약, 손절 2틱, 일일손실한도 1000, 증거금예산 5000
봉 1: 2026-11-19 10:00 KST, 종가 100, 거래량 0, 평가손익 +5
봉 2: 2026-11-19 10:05 KST, 종가 100, 거래량 12, 평가손익 -5
봉 3: 2026-11-19 10:10 KST, 종가 100, 거래량 14, 평가손익 -7

정상 대조군 입력
대조군 1: 비교값을 문자열 "0"으로 지정합니다.
  - volume > "0": 거래량이 0→12로 변할 때 봉 2에서 buyEntry 신호 1건 발생
  - openPl < "0": 평가손익이 +5→-5로 변할 때 봉 2에서 buyExit 신호 1건 발생
대조군 2: 비교값 문자열 "0.0"을 사용해도 위와 같은 신호가 각각 발생합니다.
대조군 3: 비교값 숫자 1과 문자열 "1"은 두 조건 모두 결과가 일치하고 신호가 발생합니다.
각 대조군은 원본 validate.problems 검사를 통과합니다.

오류 재현 입력
위와 같은 봉과 설정에서 비교값의 타입만 JSON 문자열 "0"에서 숫자 0으로 변경합니다.
  정상: {"left":"volume","op":"gt","rightKind":"number","right":"0"}
  오류: {"left":"volume","op":"gt","rightKind":"number","right":0}
  정상: {"left":"openPl","op":"lt","rightKind":"number","right":"0"}
  오류: {"left":"openPl","op":"lt","rightKind":"number","right":0}
둘 다 원본 전략 유효성 검사를 통과하여 저장 가능한 설정입니다.
문자열 "0"은 rules.right_at()에서 0.0으로 변환되어 봉 2에서 정상 조건·신호가 발생합니다.
숫자 0은 rules.right_at()에서 None이 되어 봉 2에서도 조건이 거짓으로 판정되며 신호가 발생하지 않습니다.
숫자 0.0과 문자열 "0.0"을 비교해도 같은 차이가 발생합니다.
이전 봉의 openPl 값은 +5로 정상 기록되어 있으므로, R22의 이전 호가 결측 문제와는 다릅니다.
결과 JSON의 bug_reproduced가 true이며 checks_passed/checks_total이 14/14입니다.

원인
backend/strategy/rules.py의 right_at()은 오른쪽이 숫자 조건이면 아래 식을 사용합니다.
   return float(str(cond.get("right") or "").strip())
파이썬에서 숫자 0과 0.0은 거짓으로 평가되므로, 위 식은 0/0.0을 빈 문자열로 바꿉니다.
이후 float("")가 ValueError를 발생시키고 함수는 None을 반환합니다.
cond_at()은 오른쪽이 None이면 비교 자체를 거짓으로 판정하여 매수 진입·청산 조건이 발동하지 않습니다.
반면 validate.py의 _filled()는 숫자 0을 입력된 값으로 인정하여 저장 검사를 통과시킵니다.
오른쪽 값이 None인 경우에만 빈 값으로 취급하고, 숫자 0과 문자열 "0"을 동일하게 숫자 0으로 파싱하도록 수정해야 합니다.
예: raw = cond.get("right"); text = "" if raw is None else str(raw).strip()
숫자 0, 0.0, 문자열 "0", "0.0"을 각각 진입/청산 테스트에 추가하면 재발을 막을 수 있습니다.
