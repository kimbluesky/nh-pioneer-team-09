#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R21: 동일 체결량을 여러 대기 지정가 주문에 중복 반영하는 버그 재현.

원본 backend.strategy.paper.PaperBook을 호출함. 합성 호가/체결만 사용.
NH API/계좌/네트워크 및 외부 패키지를 이용하지 않음.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

T0 = 1_000_000_000


def source_integrity() -> dict[str, Any]:
    """패키지에 동봉한 원본 소스 세 파일이 업로드 ZIP의 해시와 일치하는지 검사."""
    archive = Path(sys.argv[0]).resolve()
    if not zipfile.is_zipfile(archive):
        raise RuntimeError("압축 실행 파일로 실행해 주세요: python -B reproduce_R21.zip")
    with zipfile.ZipFile(archive) as z:
        manifest = json.loads(z.read("source_manifest.json"))
        results = []
        for entry in manifest["files"]:
            name = entry["path"]
            digest = hashlib.sha256(z.read(name)).hexdigest()
            results.append({"path": name, "sha256": digest, "matched": digest == entry["sha256"]})
    ok = all(item["matched"] for item in results)
    return {"passed": ok, "files": results, "archive_source_sha256": manifest["source_archive_sha256"]}


def book_of(side: str) -> dict:
    """허브의 호가 형식: 매도호가는 먼 값부터, 매수호가는 가까운 값부터."""
    if side == "buy":
        return {
            "asks": [{"price": 101.0, "quantity": 10}],
            "bids": [{"price": 100.0, "quantity": 1}, {"price": 99.0, "quantity": 10}],
        }
    return {
        "asks": [{"price": 101.0, "quantity": 10}, {"price": 100.0, "quantity": 1}],
        "bids": [{"price": 99.0, "quantity": 10}],
    }


def compact(fills: list[dict]) -> list[dict]:
    return [{"orderId": item["orderId"], "quantity": item["quantity"],
             "price": item["price"], "side": item["side"],
             "time": item["time"]} for item in fills]


def scenario(paper: Any, side: str, name: str, second_price: float | None = None) -> dict:
    """체결 1계약은 먼저 선 1계약을 소비하고, 뒤의 체결 1계약이 주문 1건만 채워야 함."""
    book = paper.PaperBook(delay=0.3)
    first = book.place("first", side=side, quantity=1, order_type=paper.LIMIT_ORDER,
                       price=100.0, at=T0)
    second = None
    if name != "one_order":
        second = book.place("second", side=side, quantity=1,
                            order_type=paper.LIMIT_ORDER,
                            price=100.0 if second_price is None else second_price,
                            at=T0 + 1)
    arrival = book.on_book(book_of(side), at=T0 + 301)
    queue_at_arrival = {o.id: o.queue_ahead for o in book.orders}
    trade_1 = {"price": 100.0, "quantity": 1}
    trade_2 = {"price": 100.0, "quantity": 1}
    fills_1 = book.on_trade(trade_1, at=T0 + 310)
    fills_2 = book.on_trade(trade_2, at=T0 + 320)
    total = sum(item["quantity"] for item in fills_2)
    return {
        "case": name, "side": side,
        "order_prices": [o.price for o in book.orders],
        "order_created_ms": [o.created for o in book.orders],
        "arrival_book": book_of(side),
        "queue_ahead_at_arrival": queue_at_arrival,
        "arrival_fills": compact(arrival),
        "first_trade": {**trade_1, "fills": compact(fills_1)},
        "second_trade": {**trade_2, "fills": compact(fills_2)},
        "second_trade_input_volume": trade_2["quantity"],
        "second_trade_output_filled": total,
        "second_trade_volume_overcount": total - trade_2["quantity"],
        "final_orders": [
            {"id": o.id, "price": o.price, "status": o.status,
             "filled": o.filled, "remaining": o.remaining,
             "queue_ahead": o.queue_ahead, "queue_done": o.queue_done}
            for o in book.orders
        ],
    }


def evaluate() -> dict:
    integ = source_integrity()
    if not integ["passed"]:
        raise RuntimeError("FAIL R21_SOURCE_INTEGRITY: 동봉 원본 파일 해시가 다릅니다")
    from backend.strategy import paper

    cases = {}
    checks = {}
    for side in (paper.BUY, paper.SELL):
        solo = scenario(paper, side, "one_order")
        same = scenario(paper, side, "two_orders_same_price")
        alternate = 99.5 if side == paper.BUY else 100.5
        diff = scenario(paper, side, "two_orders_different_price", second_price=alternate)
        cases[side] = {"one_order_control": solo, "same_price_reproduction": same,
                       "different_price_control": diff}
        checks[side + "_controls_pass"] = (
            len(solo["arrival_fills"]) == 0 and
            len(same["arrival_fills"]) == 0 and
            solo["first_trade"]["fills"] == [] and
            same["first_trade"]["fills"] == [] and
            solo["queue_ahead_at_arrival"] == {"first": 1} and
            same["queue_ahead_at_arrival"] == {"first": 1, "second": 1} and
            solo["second_trade_output_filled"] == 1 and
            diff["second_trade_output_filled"] == 1
        )
        checks[side + "_same_price_double_fill"] = (
            same["second_trade_input_volume"] == 1 and
            same["second_trade_output_filled"] == 2 and
            {f["orderId"] for f in same["second_trade"]["fills"]} == {"first", "second"} and
            [o["filled"] for o in same["final_orders"]] == [1, 1]
        )

    reproduced = bool(integ["passed"] and all(checks.values()))
    return {
        "report_id": "R21",
        "title": "동일 체결 1계약이 같은 가격의 지정가 주문 두 건에 중복 배분됨",
        "source": "nh-futures-open-api-main.zip; bundled original paper.py",
        "simulation": "offline, synthetic quotes/trades; no broker or API requests",
        "comparison": "after 1 share of public queue consumed, 1 more trade of qty=1 must fill at most 1 contract across waiting orders",
        "expected_correct_behavior": "동일 가격·방향으로 대기하는 두 주문은 시간 우선순위에 따라 체결 수량을 나눠야 함 (체결 1계약 -> 합계 최대 1계약)",
        "actual_observation": "체결 수량 1계약이 각 주문에 전부 전달되어 합계 2계약 가상 체결",
        "source_integrity": integ,
        "checks": checks,
        "bug_reproduced": reproduced,
        "cases": cases,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="R21 paper-v2 duplicate queued-fill reproduction")
    parser.add_argument("--output", type=Path, help="새 결과 JSON 경로 (기존 파일 덮어쓰기 금지)")
    args = parser.parse_args()
    result = evaluate()
    print("PASS R21_SOURCE_INTEGRITY (3/3)" if result["source_integrity"]["passed"] else "FAIL R21_SOURCE_INTEGRITY")
    for side, group in result["cases"].items():
        control = group["one_order_control"]["second_trade_output_filled"]
        duplicate = group["same_price_reproduction"]["second_trade_output_filled"]
        diff = group["different_price_control"]["second_trade_output_filled"]
        print(f"{side.upper()}: 대조 1주문 {control}, 같은 가격 2주문 {duplicate}, 다른 가격 2주문 {diff} / 입력 체결 1")
    print("검사: " + json.dumps(result["checks"], ensure_ascii=False))
    if args.output is not None:
        with args.output.open("x", encoding="utf-8") as fp:
            json.dump(result, fp, indent=2, ensure_ascii=False)
            fp.write("\n")
        print(f"결과 파일 생성: {args.output}")
    if result["bug_reproduced"]:
        print("[BUG REPRODUCED] R21 동일 체결 수량이 같은 가격의 두 지정가 주문에 중복 적용 (매수·매도)")
        return 0
    print("[NOT REPRODUCED] R21 예상한 중복 체결 현상이 확인되지 않음")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
