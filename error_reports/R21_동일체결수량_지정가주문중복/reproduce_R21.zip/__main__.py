from verify_R21 import main
raise SystemExit(main())
