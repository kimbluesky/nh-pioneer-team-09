'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert/strict');
const BASE = __dirname;
const jsx = { jsx: (type, props) => ({ type, props }), jsxs: (type, props) => ({ type, props }) };
function load(relative, dependencies, extra = {}) {
  const module = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(BASE, relative), 'utf8'), {
    module, exports: module.exports,
    require(name) {
      if (!(name in dependencies)) throw new Error('Unexpected import: ' + name);
      return dependencies[name];
    }, ...extra,
  }, { filename: relative });
  return module.exports;
}
function textOf(node) {
  if (node == null || typeof node === 'boolean') return '';
  if (typeof node !== 'object') return String(node);
  if (Array.isArray(node)) return node.map(textOf).join('');
  if (typeof node.type === 'function') return textOf(node.type(node.props));
  // The action button is not part of the result sentence.
  if (node.type === 'button') return '';
  return textOf(node.props.children);
}
(async () => {
  const cases = JSON.parse(fs.readFileSync(0, 'utf8'));
  const unused = () => { throw new Error('Unused strategy helper called'); };
  const orderable = load('compiled/orderable.cjs', {
    './environment': { accepts: unused, generation: unused },
    './strategyRules': { ORDER_TYPES: {}, needsPriceFor: unused, needsStopFor: unused },
  });
  const screen = load('compiled/OrderFormResult.cjs', { 'react/jsx-runtime': jsx });
  const results = [];
  for (const item of cases) {
    const calls = [];
    const orders = load('compiled/orders.cjs', {
      './environment': { environmentState: () => ({ active: 'paper' }) },
      './orderable': orderable,
    }, {
      fetch: async (url, options) => {
        calls.push({ url, body: JSON.parse(options.body) });
        return { ok: true, status: 200, json: async () => item.original_route_response };
      },
    });
    const result = await orders.sendOrder({
      kind: 'cancel', context: 'overseas', code: 'ZNZ26', side: item.side,
      quantity: 1, orderType: '지정가', price: 100, decimals: 0,
      originalOrderNo: '80', environment: 'paper',
    });
    assert.equal(calls.length, 1);
    assert.equal(calls[0].url, '/api/overseas/order');
    assert.equal(calls[0].body.qt_div_cd, '3');
    assert.equal(calls[0].body.environment, 'paper');
    assert.equal(result.kind, 'accepted');
    const node = screen.OrderResultLine({ sending: false, result, onOpenOrders: unused });
    results.push({ case: item.case, confirmed: result.confirmed, text: textOf(node), request: calls[0] });
  }
  process.stdout.write(JSON.stringify({ node: process.version, cases: results }));
})().catch(error => { process.stderr.write(error.stack); process.exitCode = 1; });
