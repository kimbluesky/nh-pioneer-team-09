@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "NH_REPRO_SEARCH=%~dp0"
:find_python
if exist "%NH_REPRO_SEARCH%\.venv\Scripts\python.exe" (
  set "NH_REPRO_PY=%NH_REPRO_SEARCH%\.venv\Scripts\python.exe"
  goto run
)
for %%I in ("%NH_REPRO_SEARCH%\..") do set "NH_REPRO_PARENT=%%~fI"
if /I "%NH_REPRO_PARENT%"=="%NH_REPRO_SEARCH%" goto global_python
set "NH_REPRO_SEARCH=%NH_REPRO_PARENT%"
goto find_python
:global_python
where python >nul 2>nul
if errorlevel 1 (
  echo Python을 찾지 못했습니다. NH 프로젝트 폴더 안에 압축을 풀고 다시 실행해 주세요.
  pause
  exit /b 1
)
set "NH_REPRO_PY=python"
:run
"%NH_REPRO_PY%" -B -X utf8 "%~dp0reproduce.py" --output "%~dp0result.json"
set "NH_REPRO_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %NH_REPRO_EXIT%
