"""Run the pinned original cancellation route against an in-memory API double."""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
KST = timezone(timedelta(hours=9))
COMMIT = "3311fb4e82aad59ef176599a67f21666b07e926c"
SYMBOL = "ZNZ26"
NETWORK_ATTEMPTS = []


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def block_network(*args, **kwargs):
    NETWORK_ATTEMPTS.append("blocked")
    raise RuntimeError("R20 재현은 외부 네트워크 연결을 허용하지 않습니다")


def verify_sources():
    manifest = json.loads((BASE / "source_manifest.json").read_text(encoding="utf-8"))
    check(manifest["commit"] == COMMIT, "원본 버전 불일치")
    for item in manifest["files"]:
        actual = hashlib.sha256((BASE / item["archive_path"]).read_bytes()).hexdigest()
        check(actual == item["sha256"], "파일 해시 불일치: " + item["archive_path"])
    return manifest


def row(order_no, side):
    return {
        "occurs1_ord_no": str(order_no), "occurs1_sym": SYMBOL,
        "occurs1_ord_sts": "1", "occurs1_qt_tp": "1",
        "occurs1_trd_tp": "1" if side == "buy" else "2",
        "occurs1_ord_tp": "2", "occurs1_ord_qty": "1",
        "occurs1_exec_qty": "0", "occurs1_ord_rem_qty": "1",
        "occurs1_ord_pric": "100", "occurs1_med_div": "R",
    }


class SyntheticClient:
    """The only provider boundary: no Session, credentials, HTTP or live orders."""

    def __init__(self, location, side):
        self.session = SimpleNamespace(
            config=SimpleNamespace(default_environment="paper"), is_replay=False
        )
        self.location = location
        self.side = side
        self.calls = []
        self.phase = "original_outcome_check"
        original, unrelated = row(80, side), row(90, side)
        if location == "page2":
            self.pages = {
                "": {"Occurs1": [unrelated], "nrec": "1", "nxt_key": "PAGE_2"},
                "PAGE_2": {"Occurs1": [original], "nrec": "1", "nxt_key": ""},
            }
        elif location == "page1":
            self.pages = {
                "": {"Occurs1": [unrelated, original], "nrec": "2", "nxt_key": ""}
            }
        else:
            self.pages = {"": {"Occurs1": [unrelated], "nrec": "1", "nxt_key": ""}}

    def call(self, name, payload, **kwargs):
        if name == "overseas_order":
            check(payload["qt_div_cd"] == "3", "취소 이외 요청")
            check(payload["org_ord_no"].lstrip("0") == "80", "잘못된 원주문번호")
            data = {
                "ord_no": "100", "err_cd": "00000", "org_ord_no": "80",
                "ord_qty": "1", "sym": SYMBOL, "ord_pric": "100",
            }
        elif name == "overseas_order-error":
            data = {"Occurs1": [], "nrec": "0", "nxt_key": ""}
        elif name == "overseas_order-history":
            data = self.pages[payload.get("nxt_key", "")]
        else:
            raise AssertionError("예상하지 않은 호출: " + name)
        self.calls.append({
            "phase": self.phase, "api": name,
            "request": copy.deepcopy(payload), "response": copy.deepcopy(data),
        })
        return SimpleNamespace(body=copy.deepcopy(data))


def run_backend_case(routes, account, api, outcome, Response, location, side):
    client = SyntheticClient(location, side)
    ask = routes.OverseasOrderRequest(
        environment="paper", sym=SYMBOL, side=side, qt_div_cd="3",
        glb_ord_tp_cd="2", ord_qty=1, ord_pric="100", org_ord_no="80",
    )
    # Only the waiting clock is replaced; the route, request validators,
    # provider wrappers, normalizers and outcome functions are unchanged.
    with patch.object(outcome, "sleep", lambda seconds: None):
        reply = routes.place_order(ask, Response(), client)
    queries = [
        call["request"]["nxt_key"] for call in client.calls
        if call["api"] == "overseas_order-history"
    ]

    # Independently follow every synthetic page AFTER the original check.
    # These calls are labelled separately and cannot affect its result.
    client.phase = "independent_full_history_check"
    normalized, keys, key = [], [], ""
    while True:
        check(key not in keys, "연속조회 키 순환")
        keys.append(key)
        page = account.order_history(api.order_history(next_key=key, api=client))
        normalized.extend(page["orders"])
        key = page["nextKey"]
        if not key:
            break
    original = next((item for item in normalized if item["id"] == "80"), None)
    remaining = original["remaining"] if original else 0
    expected_state = "unknown" if location in ("page1", "page2") else "accepted"
    observed_state = "accepted" if location in ("page2", "removed") else "unknown"
    check(reply["outcome"]["state"] == observed_state, "이전에 확인한 결과와 다릅니다")
    check(remaining == (0 if location == "removed" else 1), "원주문 잔량 확인 실패")
    check(queries == (["", ""] if location == "page1" else [""]), "조회 횟수/키 변경")
    return {
        "case": side + "_" + location, "side": side,
        "original_location": location, "original_remaining": remaining,
        "expected_outcome": expected_state, "actual_outcome": reply["outcome"]["state"],
        "original_history_query_keys": queries, "independent_history_query_keys": keys,
        "request_to_original_route": ask.model_dump(), "original_route_response": reply,
        "normalized_original_order": original, "synthetic_call_log": client.calls,
    }


def node_path():
    candidates = [os.environ.get("NH_REPRO_NODE"), shutil.which("node")]
    if os.environ.get("ProgramFiles"):
        candidates.append(str(Path(os.environ["ProgramFiles"]) / "nodejs/node.exe"))
    for value in candidates:
        if value and Path(value).is_file():
            return value
    raise RuntimeError("Node.js 18 이상이 필요합니다. NH 프로그램 실행 환경에서 다시 실행해 주세요.")


def execute():
    manifest = verify_sources()
    sys.path.insert(0, str(BASE / "original"))
    socket.socket.connect = block_network
    socket.socket.connect_ex = block_network
    socket.create_connection = block_network
    socket.getaddrinfo = block_network

    from fastapi import Response
    from backend import order_outcome
    from backend.overseas_futureoption import overseas_account, overseas_routes
    from backend.overseas_futureoption import overseas_futureoption_functions as api

    cases = [
        run_backend_case(overseas_routes, overseas_account, api, order_outcome, Response, location, side)
        for side in ("buy", "sell") for location in ("page2", "page1", "removed")
    ]
    process = subprocess.run(
        [node_path(), str(BASE / "ui_probe.cjs")],
        input=json.dumps(cases, ensure_ascii=False), capture_output=True,
        encoding="utf-8", cwd=BASE, timeout=30,
    )
    check(process.returncode == 0, "화면 코드 검사 실패: " + process.stderr)
    rendered = json.loads(process.stdout)
    for case, ui in zip(cases, rendered["cases"], strict=True):
        check(case["case"] == ui["case"], "사례 순서 불일치")
        check(ui["confirmed"] == (case["actual_outcome"] == "accepted"), "화면 판정 불일치")
        check(ui["text"].startswith("취소 접수됨" if case["original_location"] == "page1" else "취소됨"), "화면 문구 불일치")
        if case["original_location"] == "page1":
            check("결과 미확인" in ui["text"], "미확인 안내 누락")
        case["frontend"] = ui
    check(not NETWORK_ATTEMPTS, "외부 연결 시도가 있어 검증을 중단합니다")
    return {
        "report_id": "R20_overseas_cancel_pagination",
        "result": "DEFECT_AND_CONTROLS_REPRODUCED",
        "tested_at_kst": datetime.now(KST).isoformat(timespec="seconds"),
        "environment": {
            "platform": platform.system(), "python": platform.python_version(),
            "node": rendered["node"],
            "packages": {name: importlib.metadata.version(name) for name in ("fastapi", "pydantic", "httpx", "PyYAML")},
        },
        "source": manifest,
        "scope": {
            "nh_server_requests": 0, "actual_orders_sent": 0,
            "credentials_used": False, "browser_ui_tested": False,
            "original_business_functions_changed": False,
            "network_attempts": len(NETWORK_ATTEMPTS),
            "method": "Pinned original route, schemas, API wrappers and normalizers; synthetic client responses; original frontend sendOrder and OrderResultLine with fetch/environment/JSX boundaries replaced.",
            "pagination": "Two synthetic pages with explicit nxt_key; this does not measure the provider's page size or reproduce an actual exchange cancellation failure.",
        },
        "cases": cases,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, help="검증 결과 JSON을 저장할 경로")
    args = parser.parse_args()
    try:
        result = execute()
        if args.output:
            args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("NH FUTURES API - 해외 취소 다음 페이지 누락 재현")
        print("원본 버전: " + COMMIT[:12] + " / 원본 파일 해시 확인 완료")
        print()
        for case in result["cases"]:
            if case["side"] != "buy":
                continue
            name = {"page2": "오류 상황 (원주문 2쪽)", "page1": "비교 상황 (원주문 1쪽)", "removed": "정상 취소 (원주문 없음)"}[case["original_location"]]
            line = case["frontend"]["text"].split(" — ")[0]
            print(name + ": 잔량 " + str(case["original_remaining"]) + " / " + line)
        print("매도 주문도 위 세 가지 결과가 같습니다.")
        print()
        print("오류 상황에서 프로그램이 조회한 쪽: 1쪽만 (2쪽 미조회)")
        print("PASS R20_overseas_cancel_pagination")
        print("PASS는 오류 상황과 정상 대조군이 재현됐다는 뜻입니다.")
        print("실제 NH 서버 요청: 0건 / 실제 주문 전송: 0건")
        print("확인 시각: " + result["tested_at_kst"])
        if args.output:
            print("결과 파일: " + str(args.output.resolve()))
    except Exception as exc:
        print("FAIL R20_overseas_cancel_pagination", file=sys.stderr)
        print(type(exc).__name__ + ": " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
