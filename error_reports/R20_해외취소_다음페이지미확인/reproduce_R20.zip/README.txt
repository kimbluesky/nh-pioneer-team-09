NH FUTURES API 해외 취소 다음 페이지 누락 재현

실행 방법
1. NH 프로젝트 폴더 안에 reproduce_R20.zip을 내려받습니다.
2. ZIP을 마우스 오른쪽 버튼으로 누르고 '모두 압축 풀기'를 선택합니다.
3. 압축을 푼 폴더에서 RUN_REPRO.cmd를 더블클릭합니다.
4. PASS R20_overseas_cancel_pagination을 확인합니다.
5. 같은 폴더에 생성된 result.json이 이번 실행 결과입니다.
   GitHub에 올릴 result.json을 이 파일로 교체해도 됩니다.

NH 프로젝트의 .venv와 설치된 Node.js를 사용합니다.
Python 3.11 이상, Node.js 18 이상이 필요합니다.
독립된 환경에서 실행하는 경우 필요한 Python 패키지는
fastapi>=0.115, pydantic>=2, httpx>=0.27, PyYAML>=6 입니다.
필요하면 python -m pip install -r requirements.txt로 설치합니다.
재현 프로그램이 패키지를 자동 설치하거나 인증정보를 요청하지 않습니다.
macOS/Linux에서는 python3 -B reproduce.py --output result.json으로 실행합니다.

화면에서 확인할 것
- 오류 상황: 원주문 80이 2쪽에 잔량 1로 남아 있는데 '취소됨'
- 비교 상황: 같은 원주문이 1쪽에 있으면 '취소 접수됨 / 결과 미확인'
- 정상 취소: 원주문이 전체 내역에서 없어진 경우 '취소됨'
- 매수와 매도 방향 모두 위 세 가지를 확인합니다.
PASS는 오류와 대조군을 재현했다는 뜻이며 프로그램이 정상이라는 뜻이 아닙니다.

검증 범위
원본 OverseasOrderRequest와 place_order, API 래퍼, order_result,
order_history, order_errors, settle, look, judge_overseas, apply를 실행합니다.
서버 호출부만 메모리 안의 가상 응답으로 바꾸고 대기 시간만 생략합니다.
전체 페이지를 확인하는 별도 검사는 원본 판정이 끝난 뒤에 실행하며,
결과 파일에서 independent_full_history_check로 구분합니다.
다음 페이지 키 PAGE_2와 주문번호 80, 90, 100은 모두 합성 값입니다.
실제 서버의 페이지당 건수나 거래소의 취소 실패를 재현한 것은 아닙니다.

그 결과를 원본 프런트엔드 sendOrder와 OrderResultLine에도 전달합니다.
환경과 fetch, JSX 렌더링 경계만 시험용으로 바꿉니다.
주문유형과 가격 변환 함수는 원본 orderable.ts를 사용합니다.
실제 브라우저나 NH 앱 화면을 클릭한 시험은 아닙니다.
NH 서버 요청, 인증정보 사용, 실제 주문 전송은 모두 0건입니다.
외부 소켓 연결은 실행 시 차단합니다.

원본
https://github.com/PetterChanHyuk/nh-futures-open-api
commit: 3311fb4e82aad59ef176599a67f21666b07e926c
original/에는 이 버전의 소스와 해당 라우트를 불러오는 데 필요한 모듈이 있습니다.
source_manifest.json에 원본 경로와 SHA-256을 기록했고 실행할 때 모두 확인합니다.
compiled/는 포함된 TypeScript 원본을 CommonJS/ES2022/ReactJSX로 변환한 파일입니다.
orderable.ts의 import.meta.env.DEV만 배포 환경과 같은 false로 치환해 변환했습니다.
업무 함수의 본문은 수정하지 않았습니다.
