"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OVERSEAS_TYPE_CODE = exports.ORDERABLE_IDLE = void 0;
exports.overseasFormType = overseasFormType;
exports.priceText = priceText;
exports.canAskOrderable = canAskOrderable;
exports.askOrderable = askOrderable;
const environment_1 = require("./environment");
const strategyRules_1 = require("./strategyRules");
exports.ORDERABLE_IDLE = { status: 'idle' };
/** 해외 주문유형 코드.
 *
 *  **목록의 차례로 만들지 않고 하나씩 적습니다.** 차례에서 뽑으면 화면에 보이는
 *  줄 순서를 바꾸는 것만으로 증권사에 나가는 코드가 조용히 바뀝니다. */
exports.OVERSEAS_TYPE_CODE = {
    시장가: '1',
    지정가: '2',
    'STOP-M': '3',
    'STOP-L': '4',
};
/** 미체결 줄이 쓰는 해외 주문유형 낱말 → 폼 낱말.
 *
 *  서버의 주문 줄은 STOP 두 유형을 풀어 쓴 이름으로 적어 오고, 폼과 코드표는
 *  짧은 이름을 씁니다. 두 이름의 짝은 이 자리 하나에만 둡니다 — 정정·취소가
 *  원주문의 유형을 코드로 옮길 때 이 짝을 거쳐 위 코드표 하나로 갑니다. */
const OVERSEAS_ROW_TYPE = {
    STOP시장가: 'STOP-M',
    STOP지정가: 'STOP-L',
};
/** 해외 주문유형 낱말(폼 또는 미체결 줄)을 폼 낱말로. 모르는 낱말이면 `null`
 *  입니다 — 아는 유형으로 바꿔 두지 않습니다. */
function overseasFormType(word) {
    const form = OVERSEAS_ROW_TYPE[word] ?? word;
    return form in exports.OVERSEAS_TYPE_CODE ? form : null;
}
if (false) {
    const missing = strategyRules_1.ORDER_TYPES.overseas.filter((type) => !(type in exports.OVERSEAS_TYPE_CODE));
    if (missing.length > 0) {
        console.warn('[orderable] 코드가 없는 해외 주문유형:', missing.join(', '));
    }
}
/** 숫자를 서버가 받는 글자로 바꿉니다.
 *
 *  자릿수대로 적되, **그렇게 적어 값이 달라지면 적지 않습니다.** 분수로 값을
 *  받는 품목은 자릿수가 0 인데 실제 값에 소수가 있어, 자릿수만 믿고 자르면
 *  **보낸 값과 화면 값이 어긋납니다.** 되돌릴 수 없는 자리로 가는 값이라
 *  어긋나느니 길게 보냅니다. */
function priceText(value, decimals) {
    const digits = Math.min(8, Math.max(0, Math.trunc(decimals) || 0));
    const fitted = value.toFixed(digits);
    const text = Number(fitted) === value ? fitted : value.toFixed(8).replace(/0+$/, '').replace(/\.$/, '');
    /* 0 에 아주 가까운 음수는 「-0.00」으로 적힙니다(스프레드는 음수 가격을 씁니다).
       0 은 부호 없이 보냅니다. */
    return /^-0(\.0+)?$/.test(text) ? text.slice(1) : text;
}
/** 지금 물어볼 수 있는지.
 *
 *  **가격을 모르면 못 물어봅니다.** 두 시장 모두 주문가격이 있어야 답이 나오고
 *  (명세상 시장가에도 필수), 시장가로 물을 때는 그 종목의 지금 값을 대신
 *  싣습니다. 그 값마저 없으면 부를 수 없습니다. */
function canAskOrderable(ask) {
    if (!ask.code)
        return false;
    if (priceFor(ask) === null)
        return false;
    if (ask.context === 'overseas') {
        if (!(ask.orderType in exports.OVERSEAS_TYPE_CODE))
            return false;
        if ((0, strategyRules_1.needsStopFor)(ask.orderType) && ask.stopPrice === null)
            return false;
    }
    return true;
}
function priceFor(ask) {
    return (0, strategyRules_1.needsPriceFor)(ask.orderType) ? ask.price : ask.last;
}
/** 물어보고 값 자리가 말할 것을 돌려줍니다. **던지지 않습니다** — 실패도 화면이
 *  세워야 하는 얼굴이라 상태로 냅니다. */
async function askOrderable(ask) {
    const price = priceFor(ask);
    if (price === null)
        return { status: 'failed', failure: 'rejected' };
    const overseas = ask.context === 'overseas';
    const path = overseas ? '/api/overseas/orderable-quantity' : '/api/domestic/orderable-quantity';
    const body = overseas
        ? {
            sym: ask.code,
            side: ask.side,
            glb_ord_tp_cd: exports.OVERSEAS_TYPE_CODE[ask.orderType],
            ord_pric: priceText(price, ask.decimals),
            stop_pric: ask.stopPrice === null ? '' : priceText(ask.stopPrice, ask.decimals),
        }
        : {
            sym: ask.code,
            side: ask.side,
            ord_pric: priceText(price, ask.decimals),
            context: ask.context,
        };
    /* 어느 환경에서 물었는지 적어 둡니다. 답이 왔을 때 환경이 바뀌어 있거나 답이
       다른 환경의 것이면 그 수는 다른 계좌의 수라 세우지 않습니다 — 「다른 종목의
       답」과 같은 자리로 되돌립니다. */
    const since = (0, environment_1.generation)();
    try {
        const response = await fetch(path, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(body),
        });
        if (!(0, environment_1.accepts)(response, since))
            return { status: 'idle' };
        if (!response.ok) {
            /* 거절(502)은 다시 눌러도 같은 답이 옵니다. 나머지는 다시 불러 볼
               만합니다 — 어느 쪽인지로 「다시」 단추가 서고 안 서고가 갈립니다.
               서버가 보낸 문장과 오류 코드를 함께 담습니다. 문장이 없으면 담지 않습니다 —
               사유를 지어내면 사용자가 그것을 서버의 말로 읽습니다. */
            const said = (await response.json().catch(() => null));
            if (!(0, environment_1.accepts)(response, since))
                return { status: 'idle' };
            const text = typeof said?.detail === 'string' ? said.detail.trim() : '';
            const code = (response.headers.get('x-nh-error-code') ?? '').trim();
            return {
                status: 'failed',
                failure: response.status === 502 ? 'rejected' : 'retry',
                ...(text ? { text } : {}),
                ...(code ? { code } : {}),
            };
        }
        const reply = (await response.json());
        /* **다른 종목의 답이면 버립니다.** 누르고 나서 종목을 바꾸면 앞 종목의
           답이 뒤늦게 도착하는데, 그것이 새 종목의 값으로 서면 안 됩니다. */
        if (reply.code && reply.code !== ask.code)
            return { status: 'idle' };
        return {
            status: 'ready',
            quantity: reply.quantity ?? null,
            newQuantity: reply.newQuantity ?? null,
            closeQuantity: reply.closeQuantity ?? null,
        };
    }
    catch {
        if (since !== (0, environment_1.generation)())
            return { status: 'idle' };
        return { status: 'failed', failure: 'retry' };
    }
}
