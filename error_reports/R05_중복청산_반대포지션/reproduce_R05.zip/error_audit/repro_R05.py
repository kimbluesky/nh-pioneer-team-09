"""Offline R05 duplicate-close reproduction only. Synthetic input; no NH requests."""
from __future__ import annotations

import copy
import argparse
import hashlib
import json
import platform
import socket
import sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "upstream_fbfca3e"
COMMIT = "fbfca3ef2ac360029cb822e0fae16aa31fa1edc2"
sys.path.insert(0, str(SOURCE))
_socket_connect = socket.socket.connect
_socket_connect_ex = socket.socket.connect_ex


def no_network(*args, **kwargs):
    raise AssertionError("Network disabled: offline reproduction only")


socket.socket.connect = socket.socket.connect_ex = socket.create_connection = no_network

from fastapi import FastAPI
from fastapi.testclient import TestClient
from backend.strategy import engine, paper, runs, service, bars, backtest, validate
from backend.strategy import strategy_routes as routes
from backend.strategy.indicators import Bar
from backend.sessions import judge
from backend.sessions.hours import KST

# The imported backend modules stay pinned when the old helper prepends its root.
import repro_errors as old
import httpx
from backend.config import Config, EnvironmentConfig, MarketConfig
from backend.auth.auth_functions import TokenManager
from backend.nh_api.session import Session, LIVE
from backend.nh_api.client import TradeClient
from backend.nh_api.rate_limit import RateLimiter


def internal_loopback_only(original):
    def guarded(sock, address):
        # Windows asyncio builds its self-pipe using socketpair/loopback. This is
        # runtime plumbing, not an HTTP connection to the user's application.
        if isinstance(address, tuple) and address[0] in ("127.0.0.1", "::1"):
            return original(sock, address)
        return no_network(sock, address)
    return guarded


socket.socket.connect = internal_loopback_only(_socket_connect)
socket.socket.connect_ex = internal_loopback_only(_socket_connect_ex)


def ms(day=11, hour=10, minute=0, second=0):
    return int(datetime(2026, 11, day, hour, minute, second, tzinfo=KST).timestamp() * 1000)


def valid(draft, market="domestic"):
    found = validate.problems(draft, market=market)
    assert not validate.blocked(found), found
    return found


def made_engine(qty=1, **aux):
    made = old.make_engine(qty=qty, **aux)
    valid(made.run.draft)
    return made


def tick(made, day=11, hour=10, minute=0, price=99, second=0):
    stamp = ms(day, hour, minute, second)
    made.on_trade(dict(timestamp=stamp, price=price, quantity=1), made.run.session, at=stamp)


class MemoryService(service.RunService):
    """Replace only run lookup, response serialization and persistence hooks."""
    def __init__(self, made):
        self.made = made

    def _engine(self, run_id):
        assert run_id == self.made.run.id
        return self.made

    def _after(self, *args, **kwargs):
        pass

    def _row(self, *args, **kwargs):
        return old.state(self.made)


def client_for(made):
    app = FastAPI()
    app.include_router(routes.runs_router)
    app.dependency_overrides[routes.get_service] = lambda: MemoryService(made)
    return TestClient(app)


def post(client, made, action, stamp):
    with patch.object(routes, "_now", return_value=stamp):
        response = client.post(f"/api/strategy/runs/{made.run.id}/{action}")
    assert response.status_code == 200, response.text
    return {"status": response.status_code, "body": response.json()}


def filled_engine(qty=1, **aux):
    made = made_engine(qty=qty, **aux)
    old.first_signal(made)
    made.on_book(old.quote(ask=101, ask_qty=1, bid=100.9), at=ms(minute=2) + 300)
    return made


def duplicate_flatten():
    made = filled_engine(stopTicks="1000")
    with client_for(made) as client:
        first = post(client, made, "close", ms(minute=2, second=10))
        second = post(client, made, "close", ms(minute=2, second=11))
    made.on_book(old.quote(ask=102, ask_qty=10, bid=101, bid_qty=10), at=ms(minute=2, second=12))
    actual = old.state(made)

    control = filled_engine(stopTicks="1000")
    with client_for(control) as client:
        post(client, control, "close", ms(minute=2, second=10))
    control.on_book(old.quote(ask=102, ask_qty=10, bid=101, bid_qty=10), at=ms(minute=2, second=12))
    assert first["body"]["exit_orders"] == 1
    assert second["body"]["exit_orders"] == 2
    assert actual["position"] == -1 and old.state(control)["position"] == 0
    return dict(reproduced=True, valid_draft=True, first_http=first, second_http=second,
                after_fills=actual, single_request_control=old.state(control),
                expected="Pending exits must prevent a second full-size exit; final position must be zero.")


def main():
    manifest=json.loads((HERE/"upstream_manifest.json").read_text(encoding="utf-8"))
    assert manifest["commit"]==COMMIT
    for item in manifest["files"]:
        assert hashlib.sha256((SOURCE/item["path"]).read_bytes()).hexdigest()==item["sha256"], item["path"]
    for module in (engine,paper,runs,service,validate,routes):
        assert Path(module.__file__).resolve().is_relative_to(SOURCE.resolve())
    result=dict(commit=COMMIT,checked_at=datetime.now(KST).isoformat(),
        network="Offline synthetic reproduction; external connections blocked",
        cases={"R5_duplicate_flatten":duplicate_flatten()})
    (HERE/"R05_result.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print("PASS R5_duplicate_flatten")
    print("Two close requests: position=-1; one-request control: position=0")
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
