r"""Offline reproductions for the original NH FUTURES API sources.

Run from the repository root:
  .\.venv\Scripts\python.exe error_audit/repro_errors.py

No credentials, live API, orders, or user state files are used. Input quotes and
history are synthetic. A socket guard makes accidental network access fail.
"""
from __future__ import annotations

import copy
import hashlib
import json
from datetime import datetime, timedelta
from pathlib import Path
import socket
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def no_network(*args, **kwargs):
    raise AssertionError("This reproduction must not use the network")


socket.socket.connect = no_network
socket.socket.connect_ex = no_network
socket.create_connection = no_network

from backend.sessions.hours import KST
from backend.strategy import bars as bar_lib
from backend.strategy import engine, paper, runs, service, validate
from backend.domestic_futureoption import domestic_futureoption_functions as domestic


def at(hour=10, minute=0, second=0):
    return int(datetime(2026, 11, 11, hour, minute, second, tzinfo=KST).timestamp() * 1000)


def quote(ask=101.5, ask_qty=1, bid=101.4, bid_qty=10):
    return {
        "asks": [{"price": ask, "quantity": ask_qty}],
        "bids": [{"price": bid, "quantity": bid_qty}],
    }


def draft(qty=1, **aux):
    settings = {
        "orderType": "시장가", "priceBasis": "신호가", "stopBasis": "",
        "fillCond": "FAS", "stopTicks": "2", "takeTicks": "",
        "perOrder": str(qty), "maxHold": "5", "session": "국내 주간",
        "addWhileOpen": False, "dailyLoss": "300000", "marginBudget": "10000000",
    }
    settings.update(aux)
    return {
        "memo": "", "baseBar": "1분봉", "evalMode": "마감",
        "rules": {
            "buyEntry": {"on": True, "steps": [{"id": "s1", "join": "all", "withinBars": 0,
                "conds": [{"id": "c1", "left": "close", "op": "gt", "rightKind": "number", "right": "100"}]}]},
            **{key: {"on": False, "steps": []} for key in ("sellEntry", "buyExit", "sellExit")},
        },
        "aux": settings,
    }


def make_engine(qty=1, **aux):
    return engine.RunEngine(runs.Run(
        id="offline", version_id="offline", code="A756C000", market="domestic",
        session="domestic-day", state=runs.ARMED, qty=qty, cash=10_000_000,
        multiplier=1.0, draft=draft(qty, **aux),
    ), tick=0.05)


def trade(made, minute, price, offset=0):
    stamp = at(minute=minute) + offset
    made.on_trade({"timestamp": stamp, "price": price, "quantity": 1}, "domestic-day", at=stamp)


def first_signal(made):
    trade(made, 0, 99)
    trade(made, 1, 101)
    trade(made, 2, 101)
    assert made.run.state == runs.ENTERING


def state(made):
    return {
        "state": made.run.state, "position": made.ledger.position.quantity,
        "average_price": made.ledger.position.avg_price,
        "open_entry_quantity": made.open_entry,
        "exit_orders": sum(value == "exit" for value in made._purpose.values()),
        "orders": [{"side": row.side, "quantity": row.quantity, "filled": row.filled,
                    "status": row.status} for row in made.book.orders],
    }

