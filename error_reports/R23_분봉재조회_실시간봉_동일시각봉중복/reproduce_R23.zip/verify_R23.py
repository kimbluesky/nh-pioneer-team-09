#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R23: 과거 차트 봉과 열린 실시간 봉이 겹치면 같은 시간 봉이 중복 저장됩니다.

업로드한 공개 원본 backend.strategy.bars.BarBuilder(변경 없음)를 실행합니다.
합성 봉 및 체결만 입력하며, 네트워크·계좌·주문은 사용하지 않습니다.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


def integrity() -> dict[str, Any]:
    archive = Path(sys.argv[0]).resolve()
    if not zipfile.is_zipfile(archive):
        raise RuntimeError('재현 ZIP을 직접 실행해 주세요. 예: py -3.12 -B reproduce_R23.zip')
    with zipfile.ZipFile(archive, 'r') as z:
        manifest = json.loads(z.read('source_manifest.json').decode('utf-8'))
        checked = []
        for source in manifest['files']:
            raw = z.read(source['path'])
            digest = hashlib.sha256(raw).hexdigest()
            checked.append({
                'path': source['path'],
                'sha256': digest,
                'expected_sha256': source['sha256'],
                'bytes': len(raw),
                'passed': digest == source['sha256'] and len(raw) == source['bytes'],
            })
    return {
        'passed': len(checked) == 6 and all(row['passed'] for row in checked),
        'count': len(checked),
        'checked': checked,
        'reference_archive_sha256': manifest['source_archive_sha256'],
        'commit': manifest['commit'],
    }


def timestamp(hour: int, minute: int) -> int:
    from backend.sessions.hours import KST
    return int(datetime(2026, 11, 20, hour, minute, tzinfo=KST).timestamp()*1000)


def trade(hour: int, minute: int, price: float) -> dict[str, Any]:
    return {'timestamp': timestamp(hour, minute), 'price': price, 'quantity': 1}


def fetched(hour: int, minute: int, price: float) -> dict[str, Any]:
    return {'timestamp': timestamp(hour, minute), 'open': price,
            'high': price, 'low': price, 'close': price, 'volume': 2}


def scenario(name: str, *, historical: str = 'none', history_price: float = 99.,
             close_by_session: bool = False) -> dict[str, Any]:
    from backend.sessions.hours import KST
    from backend.strategy.bars import BarBuilder
    from backend.strategy.indicators import sma
    context = 'domestic-day'
    builder = BarBuilder('5분봉')

    if historical == 'initial_same_slot':
        builder.seed([fetched(10, 0, history_price)], context)

    builder.add(trade(10, 1, 100.0), context)

    if historical == 'while_open_same_slot':
        builder.seed([fetched(10, 0, history_price)], context)
    if historical == 'while_open_past_slot':
        builder.seed([fetched(9, 55, 98.0)], context)

    if not close_by_session:
        builder.add(trade(10, 5, 101.0), context)
        if historical == 'after_close_same_slot':
            builder.seed([fetched(10, 0, history_price)], context)
    builder.close()

    closes = [row.close for row in builder.bars]
    times = [row.timestamp for row in builder.bars]
    labels = [datetime.fromtimestamp(t / 1000, KST).strftime('%Y-%m-%d %H:%M') for t in times]
    duplicates = sorted(label for label, count in Counter(labels).items() if count > 1)
    sma3 = sma(closes, 3)
    return {
        'name': name,
        'history_mode': historical,
        'source_ohlcv': 'synthetic',
        'bars': [{'time_kst': label, 'close': close, 'volume': row.volume}
                 for label, close, row in zip(labels, closes, builder.bars)],
        'bar_count': len(builder.bars),
        'distinct_time_count': len(set(times)),
        'duplicate_times_kst': duplicates,
        'duplicate_bar_count': len(builder.bars) - len(set(times)),
        'ready_3_bars': builder.ready(3),
        'sma_period_3_last': sma3[-1] if sma3 else None,
        'closed_by_session': close_by_session,
    }


def evaluate() -> dict[str, Any]:
    check = integrity()
    if not check['passed']:
        raise RuntimeError('FAIL R23_SOURCE_INTEGRITY: 원본 파일 SHA-256 불일치')

    control = scenario('control_without_refill')
    past = scenario('control_past_only_refill', historical='while_open_past_slot')
    after = scenario('control_refill_after_close', historical='after_close_same_slot')
    bug = scenario('bug_refill_while_open', historical='while_open_same_slot')
    equal = scenario('bug_even_if_same_price', historical='while_open_same_slot', history_price=100.)
    initial = scenario('bug_initial_seed_then_live', historical='initial_same_slot')
    ending = scenario('bug_refill_then_session_close', historical='while_open_same_slot', close_by_session=True)

    target = '2026-11-20 10:00'
    checks = {
        'control_without_refill_unique': control['bar_count'] == 2 and control['duplicate_bar_count'] == 0 and not control['ready_3_bars'],
        'control_past_only_unique': past['bar_count'] == 3 and past['distinct_time_count'] == 3 and past['duplicate_bar_count'] == 0,
        'control_refill_after_close_unique': after['bar_count'] == 2 and after['duplicate_bar_count'] == 0,
        'bug_open_refill_duplicates_1000': bug['bar_count'] == 3 and bug['distinct_time_count'] == 2 and bug['duplicate_times_kst'] == [target],
        'bug_premature_ready_and_sma': bug['ready_3_bars'] and bug['sma_period_3_last'] == 100.0 and control['sma_period_3_last'] is None,
        'bug_even_same_closing_price': equal['duplicate_times_kst'] == [target],
        'bug_initial_seed_then_realtime': initial['duplicate_times_kst'] == [target],
        'bug_overlap_on_session_close': ending['bar_count'] == 2 and ending['distinct_time_count'] == 1 and ending['duplicate_times_kst'] == [target],
    }
    passed = all(checks.values())
    return {
        'report_id': 'R23',
        'description': 'overlapping historical 5-minute bar and realtime open bar yield duplicate timestamps',
        'integrity': check,
        'python_version': platform.python_version(),
        'network_used': False,
        'synthetic_data': True,
        'scenarios': {'control_without_refill': control,
                      'control_past_only_refill': past,
                      'control_refill_after_close': after,
                      'bug_refill_while_open': bug,
                      'bug_even_if_same_price': equal,
                      'bug_initial_seed_then_live': initial,
                      'bug_refill_then_session_close': ending},
        'checks': checks,
        'check_count': len(checks),
        'check_passed': sum(bool(v) for v in checks.values()),
        'bug_reproduced': passed,
        'cause': 'BarBuilder.seed inserts a historical row into closed bars even when _open occupies the same timestamp. When _open closes, close() appends without de-duplicating the timestamp.',
    }


def main() -> int:
    parser = argparse.ArgumentParser(description='R23 원본 코드 오프라인 오류 재현')
    parser.add_argument('--output', default='', help='JSON 결과 저장 경로(기존 파일 덮어쓰지 않음)')
    args = parser.parse_args()
    try:
        data = evaluate()
    except Exception as exc:
        print(f'FAIL R23: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 2
    count = data['integrity']['count']
    print(f'PASS R23_SOURCE_INTEGRITY: {count}/{count}')
    print('대조군(과거 재조회 없음): 10:00 봉 1개, 전체 봉 2개, 준비봉 3개 미달')
    print('대조군(과거 09:55만 재조회): 09:55·10:00·10:05 각 1개')
    print('대조군(10:00 실시간 봉을 닫은 후 재조회): 10:00·10:05 각 1개')
    print('오류군(10:00 진행 중 10:00 분봉 재조회): 10:00 봉 2개, 전체 봉 3개, SMA3=100, 준비봉 3개 충족으로 오인')
    print('오류군(초기 조회 후 실시간 시작 / 같은 종가 / 세션 마감): 동일 시각 중복 재현')
    print(f"검사: {data['check_passed']}/{data['check_count']}")
    if data['bug_reproduced']:
        print('[BUG REPRODUCED] R23 과거 분봉과 실시간 봉 시간 중복으로 봉 수·지표 왜곡')
    else:
        print('FAIL R23: 기대 재현 조건 미충족', file=sys.stderr)
        return 1
    if args.output:
        try:
            with open(args.output, 'x', encoding='utf-8') as stream:
                json.dump(data, stream, indent=2, ensure_ascii=False, allow_nan=False)
                stream.write('\n')
        except FileExistsError:
            print(f'결과 파일이 이미 있어 덮어쓰지 않았습니다: {args.output}', file=sys.stderr)
            return 3
        print(f'JSON 저장: {args.output}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
