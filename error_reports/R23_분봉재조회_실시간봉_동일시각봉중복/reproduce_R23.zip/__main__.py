from verify_R23 import main
raise SystemExit(main())
