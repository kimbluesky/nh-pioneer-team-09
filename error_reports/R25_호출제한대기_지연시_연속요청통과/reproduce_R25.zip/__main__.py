from verify_R25 import main

if __name__ == "__main__":
    raise SystemExit(main())
