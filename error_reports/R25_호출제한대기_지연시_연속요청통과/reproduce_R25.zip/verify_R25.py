#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R25 offline proof: RateLimiter may dispatch consecutive requests with zero gap.

Uses unchanged bundled RateLimiter and Limit definitions and a deterministic
virtual monotonic clock. No real time sleeping, networking, credentials or orders.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import zipfile
from pathlib import Path
from typing import Any

ID = 'R25'


def source_integrity() -> dict[str, Any]:
    archive = Path(sys.argv[0]).resolve()
    if not zipfile.is_zipfile(archive):
        raise RuntimeError('ZIP 직접 실행: py -3.12 -B reproduce_R25.zip')
    with zipfile.ZipFile(archive,'r') as zf:
        m = json.loads(zf.read('source_manifest.json'))
        files = []
        for row in m['files']:
            raw = zf.read(row['path'])
            digest = hashlib.sha256(raw).hexdigest()
            files.append({
                'path':row['path'], 'bytes':len(raw), 'sha256':digest,
                'expected_sha256':row['sha256'],
                'matched':len(raw)==row['bytes'] and digest == row['sha256'],
            })
    return {
        'passed': bool(files) and all(x['matched'] for x in files),
        'count':len(files),
        'source_zip_name':m['source_zip_name'],
        'source_archive_sha256':m['source_archive_sha256'],
        'git_commit_independently_verified': False,
        'files':files,
    }


class VirtualClock:
    """Controlled monotonic+sleep; oversleep mimics delayed thread scheduling."""
    def __init__(self, *, overrun:float=0.0):
        self.now = 0.0
        self.overrun = float(overrun)
        self.sleep_calls:list[dict[str,float]] = []

    def monotonic(self) -> float:
        return self.now

    def sleep(self, seconds:float) -> None:
        # Delayed scheduler wakes later than requested. One sleep is sufficient.
        began = self.now
        self.now += float(seconds)+self.overrun
        self.sleep_calls.append({
            'at':round(began,6),
            'requested_seconds':round(seconds,6),
            'actual_seconds':round(self.now-began,6),
            'overrun_seconds':round(self.overrun,6),
        })
        self.overrun=0.0


def run_case(name:str, *, kind:str, delay_overrun:float=0.0, after_first_idle:float=0.0,
             second_market:str='domestic', second_env:str='paper') -> dict[str,Any]:
    from backend.nh_api.catalog import Limit, LIMIT_PER_SECOND
    from backend.nh_api.rate_limit import RateLimiter
    tier=Limit(kind)
    clock=VirtualClock(overrun=delay_overrun)
    limit=RateLimiter(monotonic=clock.monotonic,sleep=clock.sleep)
    calls=[]
    # A returned wait() is the instant we *would* dispatch an HTTP request.
    for i in range(3):
        if i==1 and after_first_idle:
            clock.now+=after_first_idle
        env = second_env if i==1 else 'paper'
        market = second_market if i==1 else 'domestic'
        waited=limit.wait(env, market, tier)
        calls.append({
            'index':i+1,
            'market':market,
            'environment':env,
            'wait_reported_seconds':round(waited,6),
            'dispatch_second':round(clock.now,6),
        })
    gaps=[round(calls[i]['dispatch_second']-calls[i-1]['dispatch_second'],6) for i in [1,2]]
    min_gap=1.0 / LIMIT_PER_SECOND[tier]
    return {
        'case': name,
        'rate_class':kind,
        'allowed_requests_per_second':LIMIT_PER_SECOND[tier],
        'required_min_gap_seconds':round(min_gap,6),
        'virtual_oversleep_seconds':delay_overrun,
        'calls':calls,
        'consecutive_gaps_seconds':gaps,
        'sleep_calls':clock.sleep_calls,
        'last_pair_violates_gap':gaps[-1]+1e-7<min_gap,
    }


def analyze() -> dict[str,Any]:
    from backend.nh_api.catalog import Limit
    from backend.nh_api.rate_limit import RateLimiter

    normal_quote=run_case('control_quote_exact_sleep',kind='quote')
    bug_quote=run_case('bug_quote_oversleep_0_30',kind='quote',delay_overrun=.3)
    normal_order=run_case('control_order_exact_sleep',kind='order')
    bug_order=run_case('bug_order_oversleep_0_30',kind='order',delay_overrun=.3)
    idle=run_case('control_quote_idle_0_90',kind='quote',after_first_idle=.9)
    other_market=run_case('control_separate_market',kind='quote',second_market='overseas')
    other_env=run_case('control_separate_environment',kind='quote',second_env='real')

    tests = [
        ('quote rate limit is 10 calls/sec',abs(RateLimiter.interval(Limit.QUOTE)-.1)<1e-9),
        ('order rate limit is 5 calls/sec',abs(RateLimiter.interval(Limit.ORDER)-.2)<1e-9),
        ('normal quote dispatches at 0/.1/.2', [x['dispatch_second'] for x in normal_quote['calls']]==[0,.1,.2]),
        ('normal quote has no gap violation',not normal_quote['last_pair_violates_gap']),
        ('normal order dispatches at 0/.2/.4',[x['dispatch_second'] for x in normal_order['calls']]==[0,.2,.4]),
        ('normal order has no gap violation',not normal_order['last_pair_violates_gap']),
        ('quote oversleep late 2nd dispatch at .4',[x['dispatch_second'] for x in bug_quote['calls']]==[0,.4,.4]),
        ('quote oversleep returns zero wait on third call',bug_quote['calls'][2]['wait_reported_seconds']==0.0),
        ('quote oversleep violates .1 gap',bug_quote['last_pair_violates_gap']),
        ('order oversleep late 2nd dispatch at .5',[x['dispatch_second'] for x in bug_order['calls']]==[0,.5,.5]),
        ('order oversleep returns zero wait on third call',bug_order['calls'][2]['wait_reported_seconds']==0.0),
        ('order oversleep violates .2 gap',bug_order['last_pair_violates_gap']),
        ('idle control gap is respected',not idle['last_pair_violates_gap']),
        ('separate market key does not share scheduled reservation',[x['dispatch_second'] for x in other_market['calls']]==[0,0,.1]),
        ('separate environment key does not share reservation',[x['dispatch_second'] for x in other_env['calls']]==[0,0,.1]),
        ('late sleep is explicitly synthetic',bug_quote['sleep_calls'][0]['overrun_seconds']==.3),
    ]
    checks=[{'name':name,'passed':bool(value)} for name,value in tests]
    bug = all((bug_quote['last_pair_violates_gap'],bug_order['last_pair_violates_gap'])) and (
        not normal_quote['last_pair_violates_gap'] and not normal_order['last_pair_violates_gap']
    )
    return {
        'id':ID,
        'title':'RateLimiter oversleep permits zero-gap consecutive API dispatch',
        'environment':{
            'python':platform.python_version(),
            'operating_system':platform.system(),
            'no_network':True,
            'original_functions':['backend.nh_api.rate_limit.RateLimiter.wait','backend.nh_api.rate_limit.RateLimiter.interval'],
            'clock':'deterministic synthetic monotonic/sleep',
        },
        'cases':[normal_quote,bug_quote,normal_order,bug_order,idle,other_market,other_env],
        'checks_passed':sum(c['passed'] for c in checks),
        'checks_total':len(checks),
        'checks':checks,
        'bug_reproduced':bug,
        'limitations':'Injected virtual clock simulates scheduler oversleep. Actual HTTP sending/server throttling was not tested.'
    }


def main() -> int:
    p=argparse.ArgumentParser(description='R25 RateLimiter offline reproducer')
    p.add_argument('--output',help='Optional JSON path; refuses overwrite')
    args=p.parse_args()
    integ=source_integrity()
    print(f"{'PASS' if integ['passed'] else 'FAIL'} R25_SOURCE_INTEGRITY: {sum(f['matched'] for f in integ['files'])}/{integ['count']}")
    if not integ['passed']:
        return 2
    answer=analyze()
    answer['source_integrity']=integ
    for row in answer['cases'][:4]:
        stamps=[x['dispatch_second'] for x in row['calls']]
        print(f"{row['case']}: dispatch={stamps} seconds, gaps={row['consecutive_gaps_seconds']}, last_gap_violation={row['last_pair_violates_gap']}")
    print(f"CHECKS: {answer['checks_passed']}/{answer['checks_total']}")
    if answer['bug_reproduced'] and answer['checks_passed']==answer['checks_total']:
        print('[BUG REPRODUCED] R25 지연된 대기 후 시세·주문 API 요청 간 최소 간격 누락')
        code=0
    else:
        print('[NOT REPRODUCED] R25 검사 기대 결과가 일치하지 않습니다')
        code=1
    if args.output:
        output=Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        try:
            with output.open('x',encoding='utf8') as stream:
                json.dump(answer,stream,indent=2,ensure_ascii=False)
                stream.write('\n')
        except FileExistsError:
            print(f'ERROR JSON 파일이 이미 존재합니다(덮어쓰기 안 함): {output}',file=sys.stderr)
            return 3
        print(f'JSON SAVED: {output}')
    return code


if __name__=='__main__':
    raise SystemExit(main())
