R25 호출 제한 대기 지연 후 연속 API 요청 간 최소 간격 누락 / team-09

실행 방법
1. reproduce_R25.zip을 원하는 폴더에 둡니다. NH 프로젝트 설치나 ZIP 압축 해제는 필요 없습니다.
2. 탐색기 주소 칸에 powershell을 입력하고 Enter를 누릅니다.
3. 아래 명령을 실행합니다. Python 3.12 이상을 권장합니다.
   py -3.12 -B reproduce_R25.zip
   NH 프로젝트 .venv가 있다면 다음 명령도 사용할 수 있습니다.
   .\.venv\Scripts\python.exe -B reproduce_R25.zip
4. PASS R25_SOURCE_INTEGRITY와 [BUG REPRODUCED] R25를 확인합니다.
   PASS R25_SOURCE_INTEGRITY: 5/5
   시세 API 정상군: 호출 직전 통과 시각 0.00 / 0.10 / 0.20초
   시세 API 지연군: 호출 직전 통과 시각 0.00 / 0.40 / 0.40초
   주문 API 정상군: 호출 직전 통과 시각 0.00 / 0.20 / 0.40초
   주문 API 지연군: 호출 직전 통과 시각 0.00 / 0.50 / 0.50초
   CHECKS: 16/16
   [BUG REPRODUCED] R25 지연된 대기 후 시세·주문 API 요청 간 최소 간격 누락
   위 문구는 원본 RateLimiter 함수에서 오류가 재현됐다는 뜻이며, 오류를 수정했다는 의미는 아닙니다.
   결과를 별도 파일로 저장하려면 --output R25_result.json을 덧붙입니다.

검증 대상
공개 원본: PetterChanHyuk/nh-futures-open-api
원본 저장소: https://github.com/PetterChanHyuk/nh-futures-open-api
검증한 소스: nh-futures-open-api-main.zip

원본 backend/nh_api/rate_limit.py의 RateLimiter.interval()·wait()를 호출하고 backend/nh_api/catalog.py의 Limit·LIMIT_PER_SECOND를 사용합니다.
backend/nh_api/client.py의 TradeClient.call()이 API 요청 전에 RateLimiter.wait()를 호출하는 경로를 코드로 확인했으며, HTTP 송신 함수는 실행하지 않았습니다.
원본 Python 파일 5개(backend/__init__.py, nh_api/__init__.py, catalog.py, rate_limit.py, client.py)를 수정하지 않고 ZIP에 넣었습니다.
source_manifest.json에는 원본 ZIP에서 추출한 각 파일의 크기와 SHA-256이 기록되어 있습니다. 실행 시 ZIP 안에 동봉한 5개 파일의 크기·SHA-256을 검사합니다.
모든 시각은 오프라인 가상 시계의 상대 초 단위입니다. 시스템에서 실제로 0.30초 지연이 발생했다는 기록이 아닙니다.
실제 API 호출이나 서버 응답, 네트워크 호출 제한 초과(429 등)를 재현한 것은 아닙니다. 계좌, APP Key, 토큰 및 주문도 사용하지 않았습니다.
별도 패키지 설치는 필요하지 않습니다. --output이 없으면 결과 파일을 생성하지 않습니다.

설정
시계: monotonic() 및 sleep()을 주입 가능한 가상 시계로 대체. RateLimiter 함수 구현 자체는 원본 그대로 사용합니다.
동일 호출 키: 환경 paper, 시장 domestic, 시세 등급 Limit.QUOTE 또는 주문 등급 Limit.ORDER
시세 제한: 초당 10건 → 요청 사이 최소 0.10초
주문 제한: 초당 5건 → 요청 사이 최소 0.20초
측정 시점: RateLimiter.wait()가 반환되어 HTTP 전송을 시작할 수 있게 되는 시각
호출 수: 각 조건에서 연속 3회
지연군: 두 번째 호출이 요청한 대기 시간보다 0.30초 늦게 반환되는 가상 스케줄러 상황

정상 대조군 입력
대조군 1 — 시세 등급, sleep()에 지연 없음
  1번째 통과 0.00초 → 2번째 0.10초 → 3번째 0.20초, 연속 간격 0.10/0.10초
대조군 2 — 주문 등급, sleep()에 지연 없음
  1번째 통과 0.00초 → 2번째 0.20초 → 3번째 0.40초, 연속 간격 0.20/0.20초
대조군 3 — 첫 호출 후 0.90초 쉬었다가 같은 키로 다시 호출하면 다음 요청 사이의 최소 간격 유지
대조군 4 — 시장이나 환경이 다른 호출 키는 독립적으로 예약되는지 검사

오류 재현 입력
재현군 1 — 시세 등급
  첫 번째 요청: 가상 0.00초에 wait() 통과
  두 번째 요청: 0.10초를 기다리도록 예약되지만 가상 스케줄러에서 0.30초 더 지연되어 0.40초에 wait() 통과
  세 번째 요청: 직후 0.40초에 wait()를 다시 부르면 지연 0.00초를 반환하고 즉시 통과
  결과: 두 번째/세 번째 통과 간격 0.00초 < 최소 간격 0.10초
재현군 2 — 주문 등급
  첫 번째 요청: 0.00초 통과
  두 번째 요청: 0.20초 대기 + 가상 지연 0.30초 → 0.50초 통과
  세 번째 요청: 직후 0.50초, wait()가 0.00초 대기 후 통과
  결과: 두 번째/세 번째 통과 간격 0.00초 < 최소 간격 0.20초

이 결과는 실제 시스템 지연 대신 가상 시계로 원본 RateLimiter의 반환 시점을 제어한 것입니다. 호출 개수 제한만 있는 원격 서버에서 실제 오류 응답이 발생하는지까지 확인했다는 뜻은 아닙니다.
result.json의 bug_reproduced=true, checks_passed/checks_total=16/16입니다.

원인
backend/nh_api/rate_limit.py의 RateLimiter.wait()는 내부 잠금 상태에서 호출 예정 시각(next_allowed)을 먼저 갱신합니다.
   now = self._monotonic()
   allowed_at = self._next_allowed.get(key, now)
   delay = max(0.0, allowed_at - now)
   self._next_allowed[key] = max(allowed_at, now) + interval
이후 잠금을 해제한 뒤 self._sleep(delay)를 실행합니다.
   if delay > 0:
       self._sleep(delay)
실제 대기가 예정된 시각보다 오래 걸려도 이미 계산한 next_allowed는 수정되지 않습니다.
따라서 지연 후 돌아온 두 번째 호출과 직후 세 번째 호출이 같은 시각에 통과할 수 있습니다. 실제 통과(전송 개시) 시각 기준의 간격 보장이 깨지는 것입니다.
대기 후 실제 시각으로 다음 허용 시각을 조정하고, 같은 계정·시장·등급에 대해 다중 스레드 호출의 전송 시작도 순서대로 직렬화하도록 수정이 필요합니다.
예정 시간보다 늦게 깨어나는 경우와 동시에 호출하는 스레드를 회귀 테스트에 추가해주세요.
