"""R03: original strategy engine, synthetic input, no NH API requests."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import zipfile

sys.dont_write_bytecode = True
KST = timezone(timedelta(hours=9))
COMMIT = "fbfca3ef2ac360029cb822e0fae16aa31fa1edc2"

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def main():
    parser = argparse.ArgumentParser(description="Reproduce the FOK cancellation defect offline.")
    parser.add_argument("--output", help="Optional JSON output file. Existing files are not overwritten.")
    args = parser.parse_args()
    output = Path(args.output).resolve() if args.output else None
    if output is not None and output.exists():
        raise RuntimeError("Output already exists. Use a new file name.")
    archive = Path(sys.argv[0]).resolve()
    with zipfile.ZipFile(archive) as bundle:
        manifest = json.loads(bundle.read("source_manifest.json"))
        for item in manifest["files"]:
            require(hashlib.sha256(bundle.read(item["path"])).hexdigest() == item["sha256"],
                    "Original source hash mismatch: " + item["path"])
    require(manifest["commit"] == COMMIT, "Unexpected source revision")

    def guard(event, values):
        if event in ("socket.connect", "socket.connect_ex", "socket.getaddrinfo",
                     "subprocess.Popen", "os.system"):
            raise RuntimeError("This reproduction does not allow external connections or commands.")
        if event == "open":
            name, mode, flags = values
            writing = any(c in (mode or "") for c in ("w", "a", "+", "x"))
            writing = writing or bool(flags & (1 | 2 | 64 | 512 | 1024))
            if writing and (output is None or not isinstance(name, (str, bytes)) or Path(name).resolve() != output):
                raise RuntimeError("Unexpected file write prevented.")
    sys.addaudithook(guard)

    from backend.strategy import engine, paper, runs, validate
    from backend.strategy.service import RunService

    def draft(side):
        active = "buyEntry" if side == paper.BUY else "sellEntry"
        rules = {key: {"on": False, "steps": []}
                 for key in ("buyEntry", "sellEntry", "buyExit", "sellExit")}
        rules[active] = {"on": True, "steps": [{
            "id": "s1", "join": "all", "withinBars": 0, "conds": [{
                "id": "c1", "left": "close", "op": "gt" if side == paper.BUY else "lt",
                "rightKind": "number", "right": "100"
            }]
        }]}
        return {
            "memo": "", "baseBar": validate.BASE_BARS[0], "evalMode": validate.EVAL_MODE,
            "rules": rules,
            "aux": {
                "orderType": paper.LIMIT_ORDER, "priceBasis": validate.PRICE_BASES[0],
                "stopBasis": "", "fillCond": "FOK", "stopTicks": "20", "takeTicks": "20",
                "perOrder": "5", "maxHold": "5", "session": validate.SESSIONS["domestic"][0],
                "addWhileOpen": False, "dailyLoss": "300000", "marginBudget": "10000000"
            }
        }

    class SyntheticMaster:
        def locate(self, market, code):
            require(market == "domestic" and code == "A016C000", "Unexpected instrument")
            return {"rem_cnt": "30", "ctrt_size": "1"}

    def unused_clock(*args):
        raise RuntimeError("No custom session window is configured; this lookup must not occur.")

    def scenario(side, control):
        config = draft(side)
        normalized = validate.normalized({"market": "domestic"}, config)
        config = normalized or config
        save_errors = validate.problems(config, market="domestic")
        admission = RunService(store=object(), journal=object(),
                               master=SyntheticMaster(), judged=unused_clock)
        start_errors = admission.start_problems(
            draft=config, market="domestic", code="A016C000",
            session="domestic-day", qty=5, cash=10000000, fee_per_contract=0,
            mode=runs.PAPER)
        require(not save_errors and not start_errors, "Strategy settings rejected")
        run = runs.Run(id="r03-" + side + ("-control" if control else "-case"),
                       version_id="synthetic-v1", code="A016C000", session="domestic-day",
                       market="domestic", state=runs.ARMED, qty=5, cash=10000000,
                       multiplier=1, draft=config, mode=runs.PAPER)
        flow = engine.RunEngine(run, tick=0.05)
        base = int(datetime(2026, 11, 12, 10, 0, tzinfo=KST).timestamp() * 1000)
        price = 101.0 if side == paper.BUY else 99.0
        inactive = 99.0 if side == paper.BUY else 101.0
        inputs = []

        def trade(minute, value):
            at = base + minute * 60000
            data = {"price": value, "quantity": 1, "timestamp": at}
            inputs.append({"kind": "trade", "at": at, "data": data})
            flow.on_trade(data, run.session, at=at)

        def quote(minute, quantity, outside_limit=False):
            at = base + minute * 60000 + 300
            if side == paper.BUY:
                data = {"asks": [{"price": price + (0.05 if outside_limit else 0), "quantity": quantity}],
                        "bids": [{"price": price - 0.05, "quantity": 10}]}
            else:
                data = {"asks": [{"price": price + 0.05, "quantity": 10}],
                        "bids": [{"price": price - (0.05 if outside_limit else 0), "quantity": quantity}]}
            inputs.append({"kind": "book", "at": at, "data": data})
            flow.on_book(data, at=at)

        trade(0, inactive)
        trade(1, price)
        trade(2, price)
        require(len(flow.book.orders) == 1, "First strategy signal did not create one order")
        quote(2, 3, outside_limit=control)
        first = flow.book.orders[0]
        require(first.status == paper.CANCELLED and first.filled == 0 and not flow.fills,
                "First FOK must be cancelled with no fills")
        consumed_after_cancel = [
            {"side": key[0], "price": key[1], "shown": value[0], "consumed": value[1]}
            for key, value in flow.book._eaten.items()
        ]
        # A false signal followed by a true signal allows a normal second entry.
        trade(3, inactive)
        trade(4, price)
        trade(5, price)
        require(len(flow.book.orders) == 2, "Second strategy signal did not create one order")
        quote(5, 5)
        second = flow.book.orders[1]
        expected = 5 if control else 0
        require(second.filled == expected, "Observed behavior differs from reported defect")
        require(second.status == (paper.FILLED if control else paper.CANCELLED),
                "Unexpected second order status")
        require(sum(event["kind"] == engine.SIGNAL for event in flow.events) == 2,
                "Expected two normal entry signals")
        return {
            "side": side, "case": "non_marketable_first_order_control" if control else "cancelled_FOK_consumes_liquidity",
            "settings": config, "save_validation_errors": save_errors,
            "start_validation_errors": start_errors, "synthetic_inputs": inputs,
            "orders": [{"id": o.id, "side": o.side, "quantity": o.quantity, "price": o.price,
                        "fill_condition": o.fill_condition, "filled": o.filled,
                        "status": o.status, "reason": o.reason} for o in flow.book.orders],
            "consumed_after_zero_fill_cancel": consumed_after_cancel,
            "final_position": flow.ledger.position.quantity,
            "final_state": run.state, "events": flow.events, "fills": flow.fills
        }

    results = [scenario(side, control) for side in (paper.BUY, paper.SELL)
               for control in (False, True)]
    # Fail rather than silently importing any project source outside this archive.
    imported = []
    for name, module in list(sys.modules.items()):
        if name == "backend" or name.startswith("backend."):
            origin = getattr(module, "__file__", "") or ""
            require(origin.replace("\\", "/").startswith(str(archive).replace("\\", "/") + "/"),
                    "Source imported outside the pinned archive: " + name)
            imported.append(name)
    result = {
        "case_id": "R03_FOK_CANCEL_LIQUIDITY", "team": "team-09",
        "checked_at": datetime.now(KST).isoformat(),
        "source_repository": "PetterChanHyuk/nh-futures-open-api",
        "source_commit": COMMIT, "original_source_hashes_verified": len(manifest["files"]),
        "python": platform.python_version(), "platform": sys.platform,
        "scope": "Original strategy start validation and RunEngine with synthetic trades/quotes. No GUI automation or NH server requests.",
        "mocked_dependencies": ["instrument metadata for start validation", "synthetic trade and order-book inputs"],
        "modified_original_functions": [], "nh_server_requests": 0,
        "expected_behavior": "A zero-fill FOK cancellation must not consume liquidity for subsequent orders.",
        "imported_original_modules": sorted(imported), "results": results,
        "reproduced": True
    }
    if output is not None:
        with output.open("x", encoding="utf-8") as out:
            json.dump(result, out, ensure_ascii=False, indent=2)
            out.write("\n")
    print("PASS R03_FOK_CANCEL_LIQUIDITY")
    for case in results:
        first, second = case["orders"]
        print(f'{case["side"]:4} {case["case"]}: first={first["filled"]}, second={second["filled"]}, position={case["final_position"]}')
    print("PASS means the reported defect AND control were reproduced; it does not mean the program is correct.")
    print("Original strategy functions unchanged. NH server requests: 0.")
    if output is not None:
        print("Evidence saved:", output)

if __name__ == "__main__":
    main()
