"""R01: partial-fill stop-loss omission in the original paper strategy engine."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import zipfile

sys.dont_write_bytecode = True
KST = timezone(timedelta(hours=9))
COMMIT = "fbfca3ef2ac360029cb822e0fae16aa31fa1edc2"

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def main():
    parser = argparse.ArgumentParser(description="Reproduce R01 offline using original source.")
    parser.add_argument("--output", help="Optional result JSON; existing files are not overwritten.")
    args = parser.parse_args()
    output = Path(args.output).resolve() if args.output else None
    require(output is None or not output.exists(), "Output exists. Choose a new file name.")
    archive = Path(sys.argv[0]).resolve()
    with zipfile.ZipFile(archive) as bundle:
        manifest = json.loads(bundle.read("source_manifest.json"))
        require(manifest["commit"] == COMMIT, "Unexpected original source revision")
        for item in manifest["files"]:
            require(hashlib.sha256(bundle.read(item["path"])).hexdigest() == item["sha256"],
                    "Source hash mismatch: " + item["path"])

    def guard(event, values):
        if event in ("socket.connect", "socket.connect_ex", "socket.getaddrinfo", "subprocess.Popen", "os.system"):
            raise RuntimeError("Network connections and external commands are disabled.")
        if event == "open":
            name, mode, flags = values
            writing = any(c in (mode or "") for c in ("w", "a", "+", "x"))
            writing = writing or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
            if writing and (output is None or not isinstance(name, str) or Path(name).resolve() != output):
                raise RuntimeError("Unexpected file write prevented.")
    sys.addaudithook(guard)

    from backend.strategy import engine, paper, runs, validate
    from backend.strategy.service import RunService

    class SyntheticMaster:
        def locate(self, market, code):
            require(market == "domestic" and code == "A016C000", "Unexpected instrument")
            return {"rem_cnt": "30", "ctrt_size": "1"}

    def unused_clock(*args):
        raise RuntimeError("No custom session window is configured.")

    def draft(side, quantity):
        active = "buyEntry" if side == paper.BUY else "sellEntry"
        rules = {key: {"on": False, "steps": []} for key in ("buyEntry", "sellEntry", "buyExit", "sellExit")}
        rules[active] = {"on": True, "steps": [{
            "id": "s1", "join": "all", "withinBars": 0, "conds": [{
                "id": "c1", "left": "close", "op": "gt" if side == paper.BUY else "lt",
                "rightKind": "number", "right": "100"
            }]
        }]}
        return {
            "memo": "", "baseBar": validate.BASE_BARS[0], "evalMode": validate.EVAL_MODE,
            "rules": rules, "aux": {
                "orderType": paper.MARKET_ORDER, "priceBasis": validate.PRICE_BASES[0],
                "stopBasis": "", "fillCond": "FAS", "stopTicks": "2", "takeTicks": "20",
                "perOrder": str(quantity), "maxHold": "5",
                "session": validate.SESSIONS["domestic"][0], "addWhileOpen": False,
                "dailyLoss": "300000", "marginBudget": "10000000"
            }
        }

    def scenario(side, partial):
        quantity = 2 if partial else 1
        case = "partial" if partial else "full_control"
        config = draft(side, quantity)
        config = validate.normalized({"market": "domestic"}, config) or config
        save_errors = validate.problems(config, market="domestic")
        admission = RunService(store=object(), journal=object(), master=SyntheticMaster(), judged=unused_clock)
        start_errors = admission.start_problems(
            draft=config, market="domestic", code="A016C000", session="domestic-day",
            qty=quantity, cash=10000000, fee_per_contract=0, mode=runs.PAPER)
        require(not save_errors and not start_errors, "Settings rejected by original validation")
        run = runs.Run(
            id="r01-" + side + "-" + case, version_id="synthetic-v1", code="A016C000",
            session="domestic-day", market="domestic", state=runs.ARMED, qty=quantity,
            cash=10000000, multiplier=1, draft=config, mode=runs.PAPER)
        flow = engine.RunEngine(run, tick=0.05)
        base = int(datetime(2026, 11, 12, 10, 0, tzinfo=KST).timestamp() * 1000)
        entry_price = 101.0 if side == paper.BUY else 99.0
        inactive_price = 99.0 if side == paper.BUY else 101.0
        breach_price = 100.85 if side == paper.BUY else 99.15
        inputs = []

        def trade(at, price):
            data = {"price": price, "quantity": 1, "timestamp": at}
            inputs.append({"kind": "trade", "at": at, "data": data})
            flow.on_trade(data, run.session, at=at)

        for minute, price in ((0, inactive_price), (1, entry_price), (2, entry_price)):
            trade(base + minute * 60000, price)
        require(len(flow.book.orders) == 1, "Expected one order from a normal entry signal")
        if side == paper.BUY:
            book = {"asks": [{"price": entry_price, "quantity": 1}],
                    "bids": [{"price": entry_price - 0.05, "quantity": 10}]}
        else:
            book = {"asks": [{"price": entry_price + 0.05, "quantity": 10}],
                    "bids": [{"price": entry_price, "quantity": 1}]}
        at = base + 120300
        inputs.append({"kind": "book", "at": at, "data": book})
        flow.on_book(book, at=at)
        entry = flow.book.orders[0]
        require(entry.filled == 1 and abs(flow.ledger.position.quantity) == 1, "Expected exactly one filled contract")
        require(entry.remaining == (1 if partial else 0), "Unexpected unfilled entry quantity")
        before_state = run.state
        require(before_state == (runs.ENTERING if partial else runs.HOLDING), "Unexpected entry state")
        stop_price = flow._exit_lines(entry_price)[0]
        expected_stop = 100.9 if side == paper.BUY else 99.1
        require(stop_price is not None and abs(stop_price - expected_stop) < 1e-9, "Unexpected configured stop")
        trade(base + 120400, breach_price)
        exits = flow.book.orders[1:]
        require(len(exits) == (0 if partial else 1), "Result differs from reported defect")
        if not partial:
            require(exits[0].quantity == 1 and exits[0].side != side, "Expected one protective exit")
            require(flow._purpose.get(exits[0].id) == "exit", "Expected exit purpose")
            require(flow._exit_reason == engine.STOP_LOSS, "Expected stop-loss reason")
        require(flow.feed == "live", "Feed-gap path must not be involved")
        return {
            "side": side, "case": case, "settings": config,
            "save_validation_errors": save_errors, "start_validation_errors": start_errors,
            "synthetic_inputs": inputs, "requested_quantity": quantity,
            "entry_filled": entry.filled, "entry_remaining": entry.remaining,
            "position_at_stop_check": flow.ledger.position.quantity,
            "entry_price": entry_price, "tick_size": 0.05, "stop_ticks": 2,
            "stop_price": round(stop_price, 8), "breach_price": breach_price,
            "state_before_breach": before_state, "state_after_breach": run.state,
            "stop_orders_created": len(exits), "feed": flow.feed,
            "orders": [{"id": o.id, "side": o.side, "quantity": o.quantity, "filled": o.filled,
                        "remaining": o.remaining, "status": o.status,
                        "purpose": flow._purpose.get(o.id)} for o in flow.book.orders],
            "events": flow.events, "fills": flow.fills
        }

    results = [scenario(side, partial) for side in (paper.BUY, paper.SELL) for partial in (True, False)]
    imported = []
    for name, module in list(sys.modules.items()):
        if name == "backend" or name.startswith("backend."):
            origin = getattr(module, "__file__", "") or ""
            require(origin.replace("\\", "/").startswith(str(archive).replace("\\", "/") + "/"),
                    "Imported project code outside the original archive: " + name)
            imported.append(name)
    result = {
        "case_id": "R01_PARTIAL_FILL_STOP", "team": "team-09",
        "checked_at": datetime.now(KST).isoformat(),
        "source_repository": "PetterChanHyuk/nh-futures-open-api", "source_commit": COMMIT,
        "original_source_hashes_verified": len(manifest["files"]),
        "python": platform.python_version(), "platform": sys.platform,
        "scope": "Original strategy start validation and RunEngine with synthetic input; no GUI automation or NH server calls.",
        "mocked_dependencies": ["instrument metadata for admission", "synthetic trade and quote inputs"],
        "modified_original_functions": [], "nh_server_requests": 0,
        "expected_behavior": "A filled position should remain protected by the configured stop while the entry is partially filled.",
        "imported_original_modules": sorted(imported), "results": results, "reproduced": True
    }
    if output is not None:
        with output.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    print("PASS R01_PARTIAL_FILL_STOP")
    for row in results:
        print(f'{row["side"]:4} {row["case"]:12} filled={row["entry_filled"]}, remaining={row["entry_remaining"]}, stop_orders={row["stop_orders_created"]}')
    print("PASS means the reported defect and controls were reproduced.")
    print("Original strategy functions unchanged. NH server requests: 0.")
    if output is not None:
        print("Evidence saved:", output)

if __name__ == "__main__":
    main()
