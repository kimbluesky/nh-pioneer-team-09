R01 부분 체결 중 손절 누락 / team-09

실행 방법
1. Python 의존성이 준비된 NH 프로젝트 폴더에 reproduce_R01.zip을 둡니다.
2. 탐색기 주소 칸에 powershell을 입력하고 Enter를 누릅니다.
3. 아래 명령을 실행합니다. ZIP을 풀 필요는 없습니다.
.\.venv\Scripts\python.exe -B reproduce_R01.zip
4. PASS R01_PARTIAL_FILL_STOP과 다음 결과를 확인합니다.
매수·매도 partial: filled=1, remaining=1, stop_orders=0
매수·매도 full_control: filled=1, remaining=0, stop_orders=1
PASS는 오류와 비교 조건이 설명대로 재현됐다는 뜻입니다.
JSON을 저장하려면 명령 뒤에 --output R01_result.json을 붙이세요.
기존 파일은 덮어쓰지 않으므로 이미 있으면 다른 이름을 사용하세요.

검증 대상
공개 원본: PetterChanHyuk/nh-futures-open-api
커밋: fbfca3ef2ac360029cb822e0fae16aa31fa1edc2
https://github.com/PetterChanHyuk/nh-futures-open-api/tree/fbfca3ef2ac360029cb822e0fae16aa31fa1edc2

원본 시작 검사와 전략 엔진을 사용합니다. 원본 함수를 수정하거나 주문을 직접 넣지 않습니다.
합성 체결 시세가 진입 조건을 충족해 주문이 만들어지고, 원본 가상 체결 모형이 체결합니다.
종목 확인용 메타데이터, 체결 시세와 호가만 합성입니다.
앱 화면을 클릭하거나 NH API·웹소켓을 호출한 검증은 아닙니다.
계좌 키·토큰·사용자 설정은 사용하지 않습니다.
원본 파일은 source_manifest.json의 SHA256으로 검사합니다.
실행은 지정한 결과 파일 외의 쓰기와 네트워크 연결을 차단합니다.

설정
국내 주간 / 1분봉 / 마감 / 시장가 / FAS / 손절 2틱 / 익절 20틱
틱 크기 0.05 / 최대 보유 5 / 추가 진입 꺼짐
오류 조건: 주문당 2계약, 첫 호가 잔량 1
비교 조건: 주문당 1계약, 첫 호가 잔량 1
원본 저장·실행 시작 검사를 모두 통과합니다.

매수 입력
10:00 체결가 99
10:01 체결가 101
10:02 체결가 101 → 종가 > 100 규칙에서 매수 주문 생성
10:02:00.300 매도호가 101, 잔량 1 → 매수 1계약 체결
10:02:00.400 체결가 100.85 → 손절가 100.90 아래로 하락
부분 체결에서는 청산 주문 0건, 전량 체결 대조군에서는 매도 청산 1건입니다.
매도는 종가 < 100, 진입가 99, 손절가 99.10, 이후 시세 99.15로 반대로 확인합니다.
시간은 합성 시세의 시각입니다. 실제 검사 시각은 result.json의 checked_at입니다.

원인
RunEngine._take가 부분 체결을 장부에 반영해도 상태를 entering으로 남깁니다.
손절 감시는 runs.WATCH_STATES(holding, paused)만 대상으로 하므로 이 상태를 건너뜁니다.
진입 주문 중에도 이미 체결된 수량의 손절을 감시하도록 수정이 필요합니다.
