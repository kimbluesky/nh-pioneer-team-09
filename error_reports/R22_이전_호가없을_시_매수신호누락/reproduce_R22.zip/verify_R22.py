#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R22: OR 진입 규칙에서 이전 봉의 호가 값 누락이 가격 전이까지 막는 문제 재현.

사용자가 업로드한 원본 backend.strategy.rules, bars, indicators 및 sessions.hours를
수정 없이 포함하여 원본 조건 평가 함수를 호출합니다. 네트워크/계좌 접근 없음.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


def source_integrity() -> dict[str, Any]:
    archive = Path(sys.argv[0]).resolve()
    if not zipfile.is_zipfile(archive):
        raise RuntimeError("ZIP을 직접 실행해 주세요: py -3.12 -B reproduce_R22.zip")
    with zipfile.ZipFile(archive, 'r') as z:
        manifest = json.loads(z.read('source_manifest.json').decode('utf-8'))
        checked = []
        for entry in manifest['files']:
            name = entry['path']
            raw = z.read(name)
            digest = hashlib.sha256(raw).hexdigest()
            checked.append({
                'path': name,
                'sha256': digest,
                'expected_sha256': entry['sha256'],
                'bytes': len(raw),
                'matched': digest == entry['sha256'] and len(raw) == entry['bytes'],
            })
        return {
            'passed': all(item['matched'] for item in checked),
            'count': len(checked),
            'files': checked,
            'source_archive_sha256': manifest['source_archive_sha256'],
            'commit': manifest['commit'],
        }


def price_cond() -> dict[str, str]:
    return {'id': 'price_c1', 'left': 'close', 'op': 'gt', 'rightKind': 'number', 'right': '100'}


def quote_cond() -> dict[str, str]:
    return {'id': 'quote_c2', 'left': 'bid1Qty', 'op': 'gte', 'rightKind': 'number', 'right': '10'}


def as_rule(conditions: list[dict[str, str]], join: str = 'any') -> dict[str, Any]:
    return {
        'on': True,
        'steps': [{'id': 'step_1', 'join': join, 'withinBars': 0, 'conds': conditions}],
    }


def scenario(name: str, *, closes: list[float], conds: list[dict[str, str]],
             previous_quote: bool, join: str = 'any') -> dict[str, Any]:
    from backend.sessions.hours import KST
    from backend.strategy import rules
    from backend.strategy.indicators import Bar

    base = datetime(2026, 11, 18, 10, 0, tzinfo=KST)
    candles = []
    for i, close in enumerate(closes):
        stamp = int((base + timedelta(minutes=i)).timestamp() * 1000)
        candles.append(Bar(timestamp=stamp, open=close, high=close,
                           low=close, close=close, volume=10.0))
    marks = {candles[1].timestamp: {'bid1Qty': 1.0},
             candles[2].timestamp: {'bid1Qty': 1.0}}
    if previous_quote:
        marks[candles[0].timestamp] = {'bid1Qty': 1.0}

    sequence = rules.series_of(candles, marks=marks, wanted=[])
    rule = as_rule(conds, join=join)
    step = rule['steps'][0]
    fired = rules.fired_bars(rule, sequence)
    condition_table = rules.condition_table(rule, sequence, 1, *rules.stage_at(rule, sequence, 1))
    return {
        'case': name,
        'join': join,
        'closes': closes,
        'timestamps_kst': [(base + timedelta(minutes=i)).isoformat() for i in range(len(closes))],
        'bid1Qty': [sequence.at('bid1Qty', i) for i in range(len(closes))],
        'condition_descriptions': [f"{c['left']} {c['op']} {c['right']}" for c in conds],
        'price_cond_now': rules.cond_at(price_cond(), sequence, 1),
        'price_cond_before': rules.cond_at(price_cond(), sequence, 0),
        'quote_cond_now': rules.cond_at(quote_cond(), sequence, 1),
        'or_step_at_target': rules.step_at(step, sequence, 1),
        'or_step_before': rules.step_at(step, sequence, 0),
        'unknown_before': rules._unknown_before(step, sequence, 0),
        'signal_at_target': rules.fires_at(rule, sequence, 1),
        'fired_bars': fired,
        'engine_rule_keys_at_target': rules.evaluate({'buyEntry': rule}, sequence, 1),
        'condition_table_at_target': condition_table,
    }


def evaluate() -> dict[str, Any]:
    integrity = source_integrity()
    if not integrity['passed']:
        raise RuntimeError('FAIL R22_SOURCE_INTEGRITY: 업로드된 원본 기준 해시와 불일치')

    close = price_cond()
    bid_qty = quote_cond()
    # 가격 99 -> 101로 조건 A는 거짓 -> 참. 현재 호가 잔량 1 < 10으로 조건 B는 거짓.
    cases = {
        'price_only_control': scenario('가격 조건만 / 직전 호가 미수신',
                                       closes=[99.0, 101.0, 101.5], conds=[close], previous_quote=False),
        'or_missing_previous_quote': scenario('OR 조건 / 직전 호가 데이터 없음',
                                               closes=[99.0, 101.0, 101.5], conds=[close, bid_qty], previous_quote=False),
        'or_with_previous_quote_control': scenario('OR 조건 / 직전 호가 데이터 있음',
                                                   closes=[99.0, 101.0, 101.5], conds=[close, bid_qty], previous_quote=True),
        'quote_only_control': scenario('호가 조건만 / 직전 호가 미수신',
                                       closes=[99.0, 101.0, 101.5], conds=[bid_qty], previous_quote=False),
        'and_control': scenario('AND 조건 / 조건 B가 거짓',
                                closes=[99.0, 101.0, 101.5], conds=[close, bid_qty], previous_quote=False, join='all'),
        'or_no_price_cross_control': scenario('OR 조건 / 가격도 호가도 거짓',
                                              closes=[99.0, 99.5, 99.8], conds=[close, bid_qty], previous_quote=False),
    }
    a,b,c,d,e,f = (cases[k] for k in cases)
    checks = {
        'price_only_fires': a['fired_bars'] == [1] and a['signal_at_target'],
        'or_step_true_but_missing_quote_blocks_signal': (
            b['price_cond_before'] is False and b['price_cond_now'] is True
            and b['quote_cond_now'] is False and b['or_step_at_target'] is True
            and b['or_step_before'] is False and b['unknown_before'] is True
            and b['fired_bars'] == [] and b['engine_rule_keys_at_target'] == []
        ),
        'or_with_known_previous_quote_fires': (
            c['fired_bars'] == [1] and c['engine_rule_keys_at_target'] == ['buyEntry']
            and c['unknown_before'] is False
        ),
        'quote_only_false_does_not_fire': d['fired_bars'] == [],
        'and_false_does_not_fire': e['fired_bars'] == [],
        'or_without_true_condition_does_not_fire': f['fired_bars'] == [],
        'only_missing_previous_quote_changes_or_result': (
            b['closes'] == c['closes'] and b['condition_descriptions'] == c['condition_descriptions']
            and b['bid1Qty'] == [None, 1.0, 1.0]
            and c['bid1Qty'] == [1.0, 1.0, 1.0]
            and not b['signal_at_target'] and c['signal_at_target']
        ),
    }
    return {
        'report_id': 'R22',
        'title': 'OR 조건 중 다른 조건의 직전 호가 데이터가 없으면 참인 가격 전이 신호까지 누락',
        'environment': 'offline synthetic bar/quote marks; no NH API, websocket, or account',
        'python_runtime': platform.python_version(),
        'test_uses_original_functions': [
            'backend.strategy.rules.series_of',
            'backend.strategy.rules.step_at',
            'backend.strategy.rules._unknown_before',
            'backend.strategy.rules.advance',
            'backend.strategy.rules.fired_bars',
            'backend.strategy.rules.evaluate',
        ],
        'source_integrity': integrity,
        'expected_correct_behavior': (
            "OR = 하나라도 참이면 충족; 이전 호가 미수신은 가격 조건이 거짓->참으로 전환한 사실을 무효화하지 않아야 함"
        ),
        'actual_observation': (
            '가격 조건만 적용하면 buyEntry 신호 발생, OR에 이전 값이 비어 있는 bid1Qty 조건을 추가하면 신호 0건'
        ),
        'checks': checks,
        'bug_reproduced': bool(integrity['passed'] and all(checks.values())),
        'cases': cases,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description='R22 OR 조건 결측 호가로 인한 매수 신호 누락 재현')
    parser.add_argument('--output', type=Path, help='새 JSON 결과 파일 경로 (기존 파일 덮어쓰기 금지)')
    args = parser.parse_args()
    result = evaluate()
    check_count = result['source_integrity']['count']
    print(f"PASS R22_SOURCE_INTEGRITY ({check_count}/{check_count})")
    for name, case in result['cases'].items():
        print(f"{name}: price {case['closes'][0]} -> {case['closes'][1]} | "
              f"prev bid1Qty={case['bid1Qty'][0]} | step_now={case['or_step_at_target']} | "
              f"unknown_before={case['unknown_before']} | fired={case['fired_bars']}")
    print('CHECKS: ' + json.dumps(result['checks'], ensure_ascii=False, sort_keys=True))
    if args.output is not None:
        with args.output.open('x', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
            f.write('\n')
        print('결과 JSON 생성: ' + str(args.output))
    if result['bug_reproduced']:
        print('[BUG REPRODUCED] R22 OR 조건에서 직전 호가 누락 시 정상 가격 매수 신호가 차단됨')
        return 0
    print('[NOT REPRODUCED] R22: 예상한 결측 호가 신호 누락이 확인되지 않음')
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
