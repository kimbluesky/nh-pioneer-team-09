from verify_R22 import main
raise SystemExit(main())
