R22 OR 조건에서 이전 호가 값 누락으로 정상 매수 신호 미발생 / team-09

실행 방법
1. reproduce_R22.zip을 원하는 폴더에 둡니다. NH 프로젝트를 따로 설치하거나 ZIP을 풀 필요는 없습니다.
2. 탐색기 주소 칸에 powershell을 입력하고 Enter를 누릅니다.
3. 아래 명령을 실행합니다. Python 3.12 환경을 권장합니다.
   py -3.12 -B reproduce_R22.zip
   NH 프로젝트에 .venv가 준비되어 있다면 다음과 같이 실행해도 됩니다.
   .\.venv\Scripts\python.exe -B reproduce_R22.zip
4. PASS R22_SOURCE_INTEGRITY와 [BUG REPRODUCED] R22을 확인합니다.
   가격 조건만 대조군: 매수 신호 발생(봉 인덱스 1)
   OR 조건 + 이전 호가 미수신: 조건 A가 참인데도 매수 신호 미발생(오류)
   OR 조건 + 이전 호가 수신 대조군: 매수 신호 발생(봉 인덱스 1)
   호가 조건만 / AND 조건 / 양쪽 조건 거짓 대조군: 신호 미발생(정상)
   PASS R22_SOURCE_INTEGRITY는 동봉한 원본 7개 Python 파일의 SHA-256 검사가 성공했다는 뜻입니다.
   [BUG REPRODUCED]는 원본 조건식 판정에서 오류와 대조군이 재현됐다는 뜻이지, 오류가 수정됐다는 뜻이 아닙니다.
   JSON 저장이 필요하면 명령 뒤에 --output R22_result.json을 붙입니다. 기존 파일은 덮어쓰지 않습니다.

검증 대상
공개 원본: PetterChanHyuk/nh-futures-open-api
검증한 소스: nh-futures-open-api-main.zip
https://github.com/PetterChanHyuk/nh-futures-open-api

원본 backend/strategy/rules.py의 series_of, step_at, _unknown_before, advance, fired_bars, evaluate를 그대로 실행합니다.
호출에 필요한 원본 backend/strategy/indicators.py, backend/strategy/bars.py, backend/sessions/hours.py와 관련 패키지 __init__.py 3개를 포함합니다.
전략 규칙, 과거 봉 3개, 호가 잔량 기록만 합성 입력으로 제공하며 원본 조건 평가 함수를 수정하지 않습니다.
원본 RunEngine 전체의 실행이나 실제 주문 생성은 검증하지 않았습니다. RunEngine이 호출하는 원본 조건 판정 경로에 대한 오프라인 재현입니다.
source_manifest.json에 이 7개 파일의 SHA-256을 기록했습니다. 원본 ZIP으로부터 계산한 값입니다.
NH API·웹소켓·계좌·앱 UI에 접속하지 않고, 키·토큰을 사용하지 않으며, 외부 의존성 설치가 필요하지 않습니다.
--output 인수를 주지 않으면 결과 파일을 생성하지 않습니다. 포함된 result.json은 패키지 제작 시 실제 실행한 결과입니다.

설정
전략: 매수 진입(buyEntry), 1단계 조건의 결합 방식 OR(any), 청산 규칙 미사용
조건 A: 종가 close > 100
조건 B: 매수 1호가 잔량 bid1Qty >= 10
과거 봉 1: 2026-11-18 10:00 KST, 종가 99
현재 봉 2: 2026-11-18 10:01 KST, 종가 101, bid1Qty 1계약
후속 봉 3: 2026-11-18 10:02 KST, 종가 101.5, bid1Qty 1계약
시세 값과 시간은 모두 오류 검증용 합성 데이터이며 실제 서버 응답이 아닙니다.

대조군 입력
대조군 1: 조건 A만 남기고 과거 봉의 호가 기록은 비웁니다. 종가 99→101 전이에 매수 신호 1건이 발생합니다.
대조군 2: 조건 A와 B를 OR로 묶되 과거 봉(10:00)의 bid1Qty에 1을 넣습니다. 두 조건 중 A만 거짓→참이고 B는 거짓이어도 매수 신호가 발생합니다.
대조군 3: 조건 B만 적용하면 bid1Qty 1 < 10이라 신호가 나오지 않습니다.
대조군 4: A와 B를 AND로 묶으면 B가 거짓이므로 신호가 나오지 않습니다.
대조군 5: A와 B를 OR로 묶되 가격을 99→99.5→99.8로 바꾸면 둘 다 거짓이므로 신호가 나오지 않습니다.

오류 재현 입력
조건 A, B를 OR로 묶고 과거 봉(10:00)의 bid1Qty 기록만 누락시킵니다. 현재 봉(10:01)의 bid1Qty는 1로 주어 B가 거짓임을 명확히 합니다.
가격은 이전 봉 99→현재 봉 101이므로, A는 거짓→참으로 바뀌었습니다.
원본 rules.step_at은 현재 봉의 OR 단계가 참이라고 계산하지만, rules.advance는 _unknown_before가 참이라는 이유로 단계를 채우지 않습니다.
그 결과 매수 신호는 0건입니다. 동일한 규칙과 가격에서 과거 호가 값만 1로 제공하면 매수 신호 1건이 발생합니다.
후속 봉에서도 종가가 101.5로 계속 조건 A를 만족하므로 새 전이가 없고, 놓친 매수 신호는 뒤늦게 복구되지 않습니다.
result.json의 bug_reproduced 및 checks 항목이 참인 것을 확인할 수 있습니다.

원인
backend/strategy/rules.py의 advance()는 1단계 전체가 이전 봉에 거짓→현재 봉에 참이면 신호로 판정합니다.
그런데 추가로 _unknown_before()를 호출하여 첫 단계에 포함된 호가·포지션·시간 조건 중 과거 데이터가 하나라도 없는지 검사합니다.
조건을 OR(any)로 묶은 경우에도 이 결측 검사가 모든 조건에 일괄 적용되어, 다른 정상 가격 조건 A가 독립적으로 전이했는데도 전체 신호를 차단합니다.
OR 규칙에서는 전이를 확정할 수 있는 조건만으로 참이 되면 다른 가지의 결측 때문에 그 전이를 무효화하지 않아야 합니다.
조건 집계의 참·거짓·미확인 상태를 구분하여, 결측의 영향을 규칙의 실제 논리(OR/AND)에 맞게 반영하도록 수정이 필요합니다.
