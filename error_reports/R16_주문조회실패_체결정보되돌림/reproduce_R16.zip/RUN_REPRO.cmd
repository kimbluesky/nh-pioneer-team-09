@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "NH_REPRO_NODE=node"
where node >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles%\nodejs\node.exe" (
    set "NH_REPRO_NODE=%ProgramFiles%\nodejs\node.exe"
  ) else (
    echo Node.js를 찾지 못했습니다. Node.js 18 이상을 설치한 뒤 다시 실행해 주세요.
    pause
    exit /b 1
  )
)
"%NH_REPRO_NODE%" "%~dp0reproduce.cjs"
set "NH_REPRO_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %NH_REPRO_EXIT%
