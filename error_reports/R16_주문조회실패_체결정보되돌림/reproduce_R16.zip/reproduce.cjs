'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');

const ORIGINAL = {
  "repository": "https://github.com/PetterChanHyuk/nh-futures-open-api",
  "commit": "3311fb4e82aad59ef176599a67f21666b07e926c",
  "path": "frontend/src/data/account.ts",
  "source_sha256": "04443fff413d0f5082ad66f5b5f6f95b49dad311f870bffb2ea24b4c654cd3c3",
  "compiled_sha256": "5f5ad3b4426566f3e239e61967810e0a255b087d95daa212ae1cd83ee04ca3a0",
  "compiler": {
    "name": "TypeScript",
    "version": "5.9.3",
    "method": "transpileModule",
    "module": "CommonJS",
    "target": "ES2022"
  }
};
function sha256(bytes) {
  return crypto.createHash('sha256').update(bytes).digest('hex');
}
const tsBytes = fs.readFileSync(path.join(__dirname, 'original', 'account.ts'));
const jsBytes = fs.readFileSync(path.join(__dirname, 'original', 'account.cjs'));
assert.equal(sha256(tsBytes), ORIGINAL.source_sha256, 'Original TypeScript checksum mismatch');
assert.equal(sha256(jsBytes), ORIGINAL.compiled_sha256, 'Compiled JavaScript checksum mismatch');

const initialOrder = {
  id: '0000001234', code: 'A756C000', market: 'domestic-day',
  status: 'accepted', statusCode: '1', sideCode: '1', side: 'buy',
  quantity: 1, filled: 0, remaining: 1
};
// Same normalized fields as backend/realtime/feeds.py::order_event.
const fillEvent = {
  id: '0000001234', code: 'A756C000', market: 'domestic',
  status: 'filled', statusCode: '6', sideCode: '1', side: 'buy',
  quantity: 1, filled: 1, remaining: 0, fillPrice: 101
};
const clone = value => JSON.parse(JSON.stringify(value));
const response = (status, rows = []) => ({
  ok: status >= 200 && status < 300,
  status,
  headers: { get: name => name.toLowerCase() === 'x-nh-environment' ? 'paper' : null },
  json: async () => ({ orders: clone(rows), nextKey: '' })
});

async function runCase(kind) {
  const pending = [];
  const requests = [];
  const environment = {
    generation: () => 1,
    accepts: () => true,
    environmentOf: () => 'paper',
    environmentSettled: () => true,
    marketConfigured: () => true,
    onEnvironmentChange: () => () => {},
    useEnvironment: () => ({ active: 'paper' })
  };
  const react = {
    useEffect() {},
    useRef: value => ({ current: value }),
    useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot()
  };
  const allowed = {
    react,
    './environment': environment,
    '../lib/kst': { kstClock: () => '00:00' },
    '../lib/number': { MINUS: '-', currencyDigits: () => 2 }
  };
  const context = vm.createContext({
    exports: {},
    console,
    require(name) {
      if (!Object.prototype.hasOwnProperty.call(allowed, name)) {
        throw new Error('Unexpected dependency: ' + name);
      }
      return allowed[name];
    },
    fetch(url, options) {
      assert.equal(url, '/api/domestic/order-history');
      assert.equal(options.method, 'POST');
      const request = {
        index: requests.length + 1, method: options.method,
        path: url, body: JSON.parse(options.body), response: null
      };
      requests.push(request);
      return new Promise((resolve, reject) => pending.push({ resolve, reject, request }));
    },
    window: { setTimeout, clearTimeout, setInterval, clearInterval, addEventListener() {}, removeEventListener() {} },
    document: { visibilityState: 'visible', addEventListener() {}, removeEventListener() {} },
    setTimeout, clearTimeout, setInterval, clearInterval
  });
  vm.runInContext(jsBytes.toString('utf8'), context, {
    filename: 'original/account.cjs', timeout: 5000
  });
  const api = context.exports;
  const snapshot = () => {
    const entry = api.useListEntry('domestic', 'orders', 'all');
    return clone({
      rows: entry.rows, status: entry.status,
      failure: entry.failure, refreshing: entry.refreshing
    });
  };
  const answer = (request, status, rows = []) => {
    request.request.response = { status, orders: clone(rows) };
    request.resolve(response(status, rows));
  };

  let task = api.loadList('domestic', 'orders', 'all');
  answer(pending.shift(), 200, [initialOrder]);
  await task;
  const before = snapshot();

  task = api.loadList('domestic', 'orders', 'all');
  api.applyOrderEvents('domestic', [clone(fillEvent)]);
  const afterEvent = snapshot();

  const queried = pending.shift();
  if (kind === 'network_error') {
    queried.request.response = { network_error: 'Synthetic network failure' };
    queried.reject(new TypeError('Synthetic network failure'));
  } else {
    answer(queried, kind === 'http_502' ? 502 : 200, kind === 'http_200_control' ? [initialOrder] : []);
  }
  await task;
  const afterFirstResponse = snapshot();

  // The original module schedules a follow-up query when a fill arrives.
  // Let that query run normally. It fails in all three cases.
  for (let n = 0; pending.length > 0; n += 1) {
    assert.ok(n < 3, 'Unexpected retry loop');
    answer(pending.shift(), 502);
    await new Promise(resolve => setImmediate(resolve));
  }
  const final = snapshot();

  assert.equal(requests.length, 3, 'Original automatic follow-up query must run');
  assert.equal(before.rows[0].filled, 0);
  assert.equal(before.rows[0].remaining, 1);
  assert.equal(afterEvent.rows[0].filled, 1);
  assert.equal(afterEvent.rows[0].remaining, 0);
  assert.equal(afterEvent.rows[0].status, 'filled');
  const expectRollback = kind !== 'http_200_control';
  assert.equal(final.rows[0].filled, expectRollback ? 0 : 1);
  assert.equal(final.rows[0].remaining, expectRollback ? 1 : 0);
  assert.equal(final.rows[0].status, expectRollback ? 'accepted' : 'filled');
  assert.equal(final.refreshing, false);
  return {
    case: kind, initial: before, after_fill_event: afterEvent,
    after_first_response: afterFirstResponse, final, requests
  };
}

async function main() {
  const cases = [];
  for (const kind of ['http_502', 'network_error', 'http_200_control']) {
    cases.push(await runCase(kind));
  }
  const result = {
    report_id: 'order_state_rollback',
    result: 'DEFECT_AND_CONTROL_REPRODUCED',
    tested_at_kst: new Date(Date.now() + 9 * 3600000).toISOString().slice(0, 19) + '+09:00',
    environment: { platform: process.platform, arch: process.arch, node: process.version },
    source: ORIGINAL,
    scope: {
      nh_server_requests: 0,
      real_credentials_used: false,
      actual_orders_sent: false,
      browser_ui_tested: false,
      original_business_functions_changed: false,
      method: 'Original frontend data module with synthetic fetch responses and normalized order/fill event; React/environment/browser boundaries stubbed.',
      follow_up: 'Original queued follow-up query runs and receives HTTP 502 in all cases.'
    },
    inputs: { initial_order: initialOrder, fill_event: fillEvent },
    cases
  };
  if (process.argv.includes('--json')) {
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
    return;
  }
  console.log('NH FUTURES API - 주문내역 조회 실패 재현');
  console.log('원본 버전: ' + ORIGINAL.commit.slice(0, 12) + ' / 원본 파일 해시 확인 완료');
  console.log('');
  console.log('아래 숫자는 체결 수량 / 잔량입니다.');
  for (const item of cases) {
    const label = {
      http_502: '조회 실패(HTTP 502)',
      network_error: '조회 실패(통신 오류)',
      http_200_control: '정상 응답 대조군'
    }[item.case];
    const end = item.final.rows[0];
    console.log(label + ': 0/1 -> 체결 알림 1/0 -> 최종 ' + end.filled + '/' + end.remaining);
  }
  console.log('');
  console.log('PASS order_state_rollback');
  console.log('PASS는 오류 상황과 정상 대조군을 재현했다는 뜻입니다.');
  console.log('실제 NH 서버 요청: 0건 / 실제 주문 전송: 0건');
  console.log('확인 시각: ' + result.tested_at_kst);
}
main().catch(error => {
  console.error('FAIL order_state_rollback');
  console.error(error.stack || String(error));
  process.exitCode = 1;
});
