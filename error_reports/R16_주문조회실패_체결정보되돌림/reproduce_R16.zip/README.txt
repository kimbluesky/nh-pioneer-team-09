﻿NH FUTURES API 주문내역 조회 실패 재현

실행 방법
1. reproduce_R16.zip을 '모두 압축 풀기'로 풉니다.
2. 압축을 푼 폴더에서 RUN_REPRO.cmd를 더블클릭합니다.
   Node.js 18 이상이 필요합니다. npm install은 필요하지 않습니다.
   macOS/Linux에서는 같은 폴더에서 node reproduce.cjs를 실행합니다.
3. PASS order_state_rollback과 세 줄의 수량을 확인합니다.
   실패 상황: 0/1 -> 체결 알림 1/0 -> 최종 0/1
   정상 대조군: 0/1 -> 체결 알림 1/0 -> 최종 1/0
   숫자는 체결 수량 / 잔량입니다.
   PASS는 프로그램에 문제가 없다는 뜻이 아니라 오류와 대조군을 재현했다는 뜻입니다.

재현 조건
원본 loadList, applyOrderEvents, useListEntry를 실행합니다.
조회 응답을 기다리는 동안 체결 알림을 전달한 뒤,
조회에 HTTP 502 또는 통신 오류를 반환합니다.
체결 알림 때문에 원본 코드가 예약한 후속 조회도 실제로 실행하며,
모든 사례에서 이 후속 조회에는 HTTP 502를 반환합니다.
대조군은 첫 재조회만 HTTP 200으로 바꿉니다.

검증 범위
원본 프로그램에 가상 조회 응답과 정규화된 주문/체결 알림을 넣습니다.
React 구독 읽기, 브라우저 이벤트, 환경 정보, fetch만 시험용으로 대체합니다.
NH 서버 호출, 인증정보 입력, 실제 주문 전송은 없습니다.
실제 앱 화면을 클릭해서 재현한 결과는 아닙니다.

원본
https://github.com/PetterChanHyuk/nh-futures-open-api
commit: 3311fb4e82aad59ef176599a67f21666b07e926c
파일: frontend/src/data/account.ts
SHA-256: 04443fff413d0f5082ad66f5b5f6f95b49dad311f870bffb2ea24b4c654cd3c3

original/account.ts는 공개 원본 그대로입니다.
original/account.cjs는 TypeScript 5.9.3의 transpileModule로
module=CommonJS, target=ES2022 옵션을 사용해 변환했습니다.
업무 함수의 로직은 수정하지 않았으며, 실행 시 두 파일의 해시를 확인합니다.

결과를 JSON으로 출력하려면 node reproduce.cjs --json을 실행합니다.
