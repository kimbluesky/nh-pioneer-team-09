R26 401 토큰 재발급 후 API 재전송의 호출 제한 우회 / team-09

실행 방법
1. reproduce_R26.zip을 NH FUTURES API 프로젝트의 Python 가상환경을 사용할 수 있는 폴더에 둡니다. 원본 프로젝트 파일은 별도로 읽지 않으므로 ZIP 압축을 풀 필요는 없습니다.
2. 탐색기 주소 칸에 powershell을 입력하여 실행합니다.
3. 다음 명령을 실행합니다. NH 프로젝트 .venv에 필요한 HTTP·실시간 라이브러리가 설치되어 있는지 확인하세요.
   .\.venv\Scripts\python.exe -B reproduce_R26.zip
   또는 Python 환경에 필요한 라이브러리가 설치되어 있다면:
   py -3.12 -B reproduce_R26.zip
4. PASS R26_SOURCE_INTEGRITY와 [BUG REPRODUCED] R26 문구가 출력되는지 확인합니다.
   PASS R26_SOURCE_INTEGRITY: 3/3
   CHECKS: 4/4
   [BUG REPRODUCED] R26 401 토큰 재발급 후 API 재전송의 호출 제한 우회
   이 문구는 오류가 재현됐다는 의미이지, 오류가 수정됐다는 뜻이 아닙니다.
5. 결과 JSON 저장 시 아래처럼 --output 옵션을 덧붙입니다.
   .\.venv\Scripts\python.exe -B reproduce_R26.zip --output R26_result.json

검증 대상
공개 원본: PetterChanHyuk/nh-futures-open-api
원본 저장소: https://github.com/PetterChanHyuk/nh-futures-open-api
검증 소스: nh-futures-open-api-main.zip
주요 코드: backend/nh_api/client.py (TradeClient.call)
원본 Python 파일을 수정하지 않고 ZIP에 넣고, 검증 코드가 실행 시 원본 파일 3개의 SHA-256을 검사합니다.
검증 대상 관련 파일 (3개):
  backend/nh_api/client.py
  backend/nh_api/catalog.py
  backend/nh_api/error_codes.py
패키지에는 임포트 의존성을 위해 원본 backend/ Python 소스들이 함께 들어 있습니다. 무결성 검사는 source_manifest.json에 표시된 대상 3개에 한합니다.
테스트 인자는 합성 데이터이고, 검증 코드는 실제 NH 서버에 접속하지 않습니다.
계좌, APP Key, 시크릿, 토큰, 실제 주문을 사용하거나 저장하지 않습니다.
Windows의 Python 3.12 실행은 별도 검증하지 않았고, 패키지는 Python 3.13.5에서 실행했습니다.

설정
모의 국내 현재가 조회; 정상 200 응답과 401 → 200 응답을 가상 HTTP Response로 비교; 실제 서버 호출 없음

정상 대조군 입력
200 정상 응답 1회: HTTP 전송 1회, 제한기 대기 1회
정상 대조군은 재현 스크립트에 포함되어 자동으로 실행됩니다.

오류 재현 입력
401 토큰 재발급 필요 응답 → 200 정상 응답: HTTP 전송 2회인데 제한기 대기 1회
자동 검사 결과:
  정상 응답: 전송 1회/대기 1회 : PASS
  401 후 정상: 실제 요청 2회 발생 : PASS
  401 재전송: 제한기 호출은 1회뿐 : PASS
  동일 제한 등급의 모든 전송은 사전 호출 제한기 필요 : PASS
result.json의 bug_reproduced=true는 정해진 오류·대조 조건 모두가 관찰된 경우에만 부여합니다.

원인
client.py의 call()은 처음 _send() 전에만 _limiter.wait()를 실행하고 401 분기에서 두 번째 _send()를 직접 실행합니다.

영향
토큰 만료 상황에서 인증 재시도 요청이 다른 호출과 겹칠 때 초당 API 요청 횟수 제어가 깨질 수 있습니다.

개선 제안
TradeClient.call()에서 401 이후의 두 번째 _send() 전에 동일 환경·시장·등급의 RateLimiter.wait()를 호출하도록 수정하고 재시도 경로의 속도 제한을 회귀 검증해 주세요.
