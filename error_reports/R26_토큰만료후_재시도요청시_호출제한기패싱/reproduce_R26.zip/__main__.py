# -*- coding: utf-8 -*-
"""Off-line reproduction; no NH API calls, no credentials."""
import sys, json, zipfile, hashlib, pathlib, argparse, datetime
RUN_ID = 'R26'
REPORT_NAME='NH FUTURES API: 토큰 만료 뒤 재시도한 요청은 호출 제한기를 거치지 않습니다'
checks=[]
def check(label,passed,observed=None,expected=None):
    checks.append({'name':label,'passed':bool(passed),'observed':observed,'expected':expected})

archive_path=pathlib.Path(sys.argv[0]).resolve()
with zipfile.ZipFile(archive_path) as archive:
    manifest=json.loads(archive.read('source_manifest.json'))
    failed=[]
    for item in manifest['files']:
        content=archive.read(item['path'])
        if len(content)!=item['bytes'] or hashlib.sha256(content).hexdigest()!=item['sha256']:
            failed.append(item['path'])
    if failed:
        print('FAIL '+RUN_ID+'_SOURCE_INTEGRITY:',failed)
        sys.exit(2)
print('PASS '+RUN_ID+'_SOURCE_INTEGRITY: '+str(len(manifest['files']))+'/'+str(len(manifest['files'])))



from types import SimpleNamespace
import httpx
from backend.nh_api.client import TradeClient
class Limiter:
    def __init__(self): self.calls=[]
    def wait(self, env, market, tier): self.calls.append([env,market,str(tier)]); return 0
class Tokens:
    def __init__(self): self.forgot=[]
    def forget(self, market, env): self.forgot.append([market,env])
class Config:
    default_environment='paper'
    def market(self, market, environment): return True

def simulate(statuses):
    limiter=Limiter(); tokens=Tokens()
    session=SimpleNamespace(config=Config(),tokens=tokens)
    obj=TradeClient(session,limiter=limiter)
    sent=[]
    def fake_send(spec,payload,env):
        n=len(sent)
        sent.append({'api':spec.api_id,'environment':env,'status':statuses[n]})
        if statuses[n]==401: return httpx.Response(401,json={'errorCode':'EGW052','errorMessage':'token expired'})
        return httpx.Response(200,json={'nrec':'1','Occurs1':[{'value':'ok'}]})
    obj._send=fake_send
    result=obj.call('domestic_price',{'sym':'A016C000'},environment='paper')
    return {'http_status':result.http_status,'sent':sent,'rate_waits':len(limiter.calls),'token_forgets':len(tokens.forgot)}
normal=simulate([200]); retry=simulate([401,200])
check('정상 응답: 전송 1회/대기 1회', len(normal['sent'])==1 and normal['rate_waits']==1, normal)
check('401 후 정상: 실제 요청 2회 발생',len(retry['sent'])==2 and retry['http_status']==200,retry)
check('401 재전송: 제한기 호출은 1회뿐',retry['rate_waits']==1 and retry['token_forgets']==1,retry)
check('동일 제한 등급의 모든 전송은 사전 호출 제한기 필요',retry['rate_waits'] < len(retry['sent']),retry)
observed={'normal':normal,'reissue_retry':retry}


passed=sum(1 for one in checks if one['passed'])
result={'case':'R26','title':REPORT_NAME,'source_integrity':{'checked':len(manifest['files']),'passed':len(manifest['files'])},'checks_passed':passed,'checks_total':len(checks),'checks':checks,'observed':observed,'bug_reproduced': bool(checks) and passed==len(checks),'verification':'offline-original-source-with-synthetic-input-no-NH-network'}
print('CHECKS: {}/{}'.format(passed,len(checks)))
if result['bug_reproduced']:print('[BUG REPRODUCED] '+RUN_ID+' '+'401 토큰 재발급 후 API 재전송의 호출 제한 우회')
else:print('[FAILED] '+RUN_ID+' '+'401 토큰 재발급 후 API 재전송의 호출 제한 우회')
parser=argparse.ArgumentParser()
parser.add_argument('--output',default='',help='Save JSON to a new file without overwriting it')
args=parser.parse_args()
if args.output:
    target=pathlib.Path(args.output)
    with target.open('x',encoding='utf-8') as handle:
        json.dump(result,handle,ensure_ascii=False,indent=2,allow_nan=False)
if not result['bug_reproduced']:sys.exit(1)
